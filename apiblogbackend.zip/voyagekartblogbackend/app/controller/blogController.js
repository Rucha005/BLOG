'use strict';
const fs = require('fs');
var Blog = require('../model/blogModel.js');

//list all categories
exports.listAllBlogs = function (req, res) {
    Blog.getAllBlog(function (err, blog) {
        if (err)
            res.send(err);
        res.send(blog);
    });
};

// create blog data
exports.createBlog = function (req, res) {
    var newblog = new Blog(req.body);
    //handles null error 
    if (!newblog.name) {
        res.status(400).send({ error: true, message: 'Please provide blog' });
    }
    else {
        Blog.createBlog(newblog, function (err, blog) {
            if (err)
                res.send(err);
            res.json(blog);
        });
    }
};

// upload image
exports.createBlog = function (req, res) {
    var newblog = new Blog(req.body);
    //handles null error 
    if (!newblog.name) {
        res.status(400).send({ error: true, message: 'Please provide blog' });
    }
    else {
        Blog.createBlog(newblog, function (err, blog) {
            if (err)
                res.send(err);
            res.json(blog);
        });
    }
};

//get blog id wise data
exports.readBlog = function (req, res) {
    Blog.getBlogById(req.params.blogid, function (err, blog) {
        if (err)
            res.send(err);
        res.json(blog);
    });
};

//update blog
exports.updateBlog = function (req, res) {
    Blog.updateById(req.params.blogid, new Blog(req.body), function (err, blog) {
        if (err)
            res.send(err);
        res.json(blog);
    });
};

// delete blog
exports.deleteBlog = function (req, res) {
    Blog.remove(req.params.blogid, function (err, blog) {
        if (err)
            res.send(err);
        res.json({ message: 'Blog successfully deleted' });
    });
};

//get category name
exports.getCategoryName = function (req, res) {
    Blog.getCategoryName(req.params.categoryid, function (err, blog) {
        if (err)
            res.send(err);
        res.json(blog);
    });
};

//get feature blog post
exports.getFeaturedBlogData = function (req, res) {
    Blog.getFeaturedBlogData(req.params.blogid, function (err, blog) {
        if (err)
            res.send(err);
        res.json(blog);
    });
};

//get category wise data
exports.getCategoryData = function (req, res) {
    Blog.getCategoryData(req.params.categoryid, function (err, blog) {
        if (err)
            res.send(err);
        res.json(blog);
    });
};

// exports.uploadFile = function (req, res) {
//     Blog.uploadFile(function (err, blog) {
//         if (err)
//             res.send(err);
//         res.json(blog);
//         console.log('here in controller');
// 	    res.send('File uploaded successfully! -> filename = ' + req.file.filename);
//     });
// };

// // upload image into folder
// exports.uploadFile = (req, res) => {
//     console.log('here in controller');
// 	res.send('File uploaded successfully! -> filename = ' + req.file.filename);
// }