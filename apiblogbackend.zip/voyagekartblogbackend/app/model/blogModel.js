'user strict';
var sql = require('../db.js');

//Blog object constructor
var Blog = function (blog) {
    this.name = blog.name;
    this.posted_on = blog.posted_on;
    this.userid = 3;
    this.categoryid = blog.categoryid;
    this.image = blog.image;
    this.shortinformation = blog.shortinformation;
    this.description = blog.description;
    this.create_date = new Date();
};

// get category data by id
Blog.getAllBlog = function getAllBlog(result) {
    sql.query("Select *,a.image,a.name,a.description,b.name as categoryname FROM blog AS a INNER JOIN category AS b ON b.categoryid = a.categoryid order by create_date desc",function (err, res) {
      if (err) {
        console.log("error: ", err);
        result(null, err);
      }
      else {
        console.log('blogs : ', res);
        result(null, res);
      }
    });
};

// create new blog
Blog.createBlog = function createBlog(newBlog, result) {
    sql.query("INSERT INTO blog set ?", newBlog, function (err, res) {
        if (err) {
            console.log("error: ", err);
            result(err, null);
        }
        else {
            result(null, res.insertId);
        }
    });
};

//get all category 
Blog.getBlogById = function createUser(blogid, result) {
    sql.query("Select *,a.image,a.name,a.description,b.name as categoryname from blog AS a INNER JOIN category AS b ON b.categoryid = a.categoryid where blogid = ? ", blogid, function (err, res) {
        if (err) {
            console.log("error: ", err);
            result(err, null);
        }
        else {
            result(null, res);

        }
    });
};

//update blog by id
Blog.updateById = function (blogid, blog, result) {
    sql.query("UPDATE blog SET name = ?, posted_on = ?, userid = ?, categoryid = ?, image = ?, shortinformation = ?, description = ?,create_date = ?  WHERE blogid = ?", [blog.name,blog.posted_on,blog.userid,blog.categoryid,blog.image,blog.shortinformation,blog.description,blog.create_date,blogid], function (err, res) {
        if (err) {
            console.log("error: ", err);
            result(null, err);
        }
        else {
            result(null, res);
        }
    });
};

//delete blog by id
Blog.remove = function (blogid, result) {
    sql.query("DELETE FROM blog WHERE blogid = ?", [blogid], function (err, res) {

        if (err) {
            console.log("error: ", err);
            result(null, err);
        }
        else {
            result(null, res);
        }
    });
};

//get category name
Blog.getCategoryName =function (categoryid, result) {
    sql.query("Select * FROM category WHERE categoryid = ?", [categoryid], function (err, res) {

        if (err) {
            console.log("error: ", err);
            result(null, err);
        }
        else {
            result(null, res);
        }
    });
};

//get all data category wise
Blog.getCategoryData =function (categoryid, result) {
    sql.query("Select * FROM blog WHERE categoryid = ?", [categoryid], function (err, res) {
        if (err) {
            console.log("error: ", err);
            result(null, err);
        }
        else {

            result(null, res);
        }
    });
}; 

//get all data category wise
Blog.getFeaturedBlogData =function (blogid, result) {
    sql.query("Select * FROM blog WHERE blogid NOT IN (?)",[blogid], function (err, res) {
        if (err) {
            console.log("error: ", err);
            result(null, err);
        }
        else {
            result(null, res);
        }
    });
};

module.exports = Blog;