import { AllProductsModule } from './allproducts.module';

describe('AllProductsModule', () => {
  let allProductsModule: AllProductsModule;

  beforeEach(() => {
    allProductsModule = new AllProductsModule();
  });

  it('should create an instance', () => {
    expect(allProductsModule).toBeTruthy();
  });
});
