import { LOCAL_STORAGE } from '@ng-toolkit/universal';
import { Component, OnInit,HostListener , Inject} from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators, FormControl, AbstractControl } from '@angular/forms';
import { RouterModule, ActivatedRoute, Router} from '@angular/router';
import { Products } from '../../products/products/products';
import { Level } from '../../display-levels/display-levels/Level';
import { ProductService } from '../../common/product.service';
import { RegistartionService } from '../../common/registartion.service';
import { ProductCartService } from '../../common/product-cart.service';
import { LoginService } from '../../login/login/login.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'app-allproducts',
  templateUrl: './allproducts.component.html',
  styleUrls: ['./allproducts.component.css']
})
export class AllProductsComponent implements OnInit {

  cartitems: any;
  customerId: any;
  pagedItems: any[];
  items: Products[] = [];
  selectedSortingValue : number ;
  productErrorMessage: string;
  _Sortform: FormArray;
  sortLevel = 
  [
      new Level(1, 'Low To High' ),
      new Level(2, 'High To Low' ),
  ];

  constructor(@Inject(LOCAL_STORAGE) private localStorage: any,private spinnerService: Ng4LoadingSpinnerService,private productService: ProductService,private registrationservice: RegistartionService,
  private route: ActivatedRoute,private router: Router,private _fb: FormBuilder,private loginService :LoginService,private cartService:ProductCartService) 
  {        
    this.selectedSortingValue =1;
    if(this.loginService.isLoggedIn())
    {
      this.getByUsername();
    } 
    else
    {
      this.spinnerService.show();
      this.productService.getAllProducts('asc',0)
      .subscribe(items => 
      {
        this.spinnerService.hide();
        this.pagedItems = items;
        this.items = null; 
        this.productErrorMessage = null;
        this.loadAllDataInAsc();
        this.productService.getAllProducts('asc',0).subscribe(s => 
        { 
          this.items = s;
        },
        (error) =>  
        {   
          this.spinnerService.hide();
          this.productErrorMessage ="Sorry No Products Found!"
          this.pagedItems = null; 
        });    
      },
      (error) =>
      {
        this.spinnerService.hide();
      })
    } 
    this._Sortform = this._fb.array([]);    
  }

  ngOnInit() 
  {
    this._Sortform = this._fb.array([]);
  } 

   /** get customer name after login */
  getByUsername() 
  {
    if( this.localStorage.getItem('currentUser') )
    {
      const currentUser = JSON.parse(this.localStorage.getItem('currentUser'));
      if (currentUser) 
      {
        this.spinnerService.show();   
        this.registrationservice.getByUsername(currentUser.username)
        .subscribe(c => 
        {
          this.spinnerService.hide();   
          this.customerId = c.userId 
          this.loadAllDataInAsc();
        },
        (error)=>
        {
          this.spinnerService.hide();   
        });
      }
    }
  }
 
  /** display all products data in ascending*/                  
  loadAllDataInAsc() 
  {
    if(this.customerId > 0)
    {
      this.selectedSortingValue = 1;
      this.productErrorMessage = null;
      this.pagedItems = null; 
      this.spinnerService.show();
      this.productService.getAllProducts('asc',this.customerId).subscribe(items => 
      { 
        this.spinnerService.hide();
        this.pagedItems = items;
      },
      (error ) =>  
      {   
        this.spinnerService.hide();
        this.productErrorMessage ="Sorry No Products Found!"
        this.pagedItems = null; 
      });  
    }
    else
    {
      this.selectedSortingValue = 1;
      this.productErrorMessage = null;
      this.pagedItems = null; 
      this.spinnerService.show();
      this.productService.getAllProducts('asc',0).subscribe(items => 
      { 
        this.spinnerService.hide();
        this.pagedItems = items;
        this.cartitems = this.cartService.loadAllCartFromLocalStorage();
        for(let p=0; p<this.pagedItems.length; p++ )
        {
          if(this.cartitems)
          {
            for(let product=0; product< this.cartitems.length;product++)
            {
              if(this.cartitems[product].modelId == this.pagedItems[p].modelId)
              {
                this.pagedItems[p].cartType = this.cartitems[product].cartType;
              }
            }
          } 
        }
      },
      (error ) =>  
      {   
          this.spinnerService.hide();
          this.productErrorMessage ="Sorry No Products Found!"
          this.pagedItems = null; 
      })
    }
  }

  /** display all products data in desc */
  loadAllDataInDesc() 
  {
    if(this.customerId > 0)
    {
      this.pagedItems = null;
      this.productErrorMessage = null;
      this.spinnerService.show();
      this.productService.getAllProducts('desc',this.customerId).subscribe(items => 
      { 
        this.spinnerService.hide();
        this.pagedItems = items;
      },
      (error) =>  
      {   
        this.spinnerService.hide();
        this.productErrorMessage ="Sorry No Products Found!"
        this.pagedItems = null;    
      });
    }
    else
    {
      this.selectedSortingValue = 1;
      this.productErrorMessage = null;
      this.pagedItems = null; 
      this.spinnerService.show();
      this.productService.getAllProducts('desc',0).subscribe(items => 
      { 
        this.spinnerService.hide();
        this.pagedItems = items;
        this.cartitems = this.cartService.loadAllCartFromLocalStorage();
        for(let p=0; p<this.pagedItems.length; p++ )
        {
          if(this.cartitems)
          {
            for(let product=0; product< this.cartitems.length;product++)
            {
              if(this.cartitems[product].modelId == this.pagedItems[p].modelId)
              {
                this.pagedItems[p].cartType = this.cartitems[product].cartType;
              }
            }
          } 
        }
      },
      (error) =>  
      {   
        this.spinnerService.hide();
        this.productErrorMessage ="Sorry No Products Found!"
        this.pagedItems = null; 
      })
    } 
  }

  /** get sorted value(high to low / low to high) and load data  */
  sort(value) 
  {
    if ( value === '2') 
    {
      if(this._Sortform.length <= 0)
      this.loadAllDataInDesc();
    } 
    else if ( value === '1' ) 
    {
      if(this._Sortform.length <= 0)
      this.loadAllDataInAsc();
    }     
  }

  /** navigate to product details page */
  navigate(event,modelId,rentTransactionId)
  {
    this.localStorage.removeItem('leveloneid');
    this.router.navigate(['/product/', modelId ,rentTransactionId])
    event.preventDefault();
    event.stopPropagation();
  }

}
