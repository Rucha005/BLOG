import { TestBed, inject } from '@angular/core/testing';

import { AllproductsService } from './allproducts.service';

describe('AllproductsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AllproductsService]
    });
  });

  it('should be created', inject([AllproductsService], (service: AllproductsService) => {
    expect(service).toBeTruthy();
  }));
});
