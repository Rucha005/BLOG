import { Routes, RouterModule } from "@angular/router";
import { AuthGuardService } from "./common/auth-guard.service";
import { NgModule } from "@angular/core";

import { BlogcategoryComponent } from "./blogcategory/blogcategory.component";
import { BlogComponent } from "./blog/blog.component";
import { BlogFeComponent } from "./blog-fe/blog-fe.component";
import { BlogDetailComponent } from "./blog-detail/blog-detail.component";

const routes: Routes = [
      {
        path:'', 
        loadChildren : './home/home.module#HomeModule'
      },  
      {
        path:'home', 
        loadChildren : './home/home.module#HomeModule'
      },     
      {
        path:'productlist/:name/:id',
        loadChildren : './display-levels/display-levels.module#DisplayLevelsModule'
      },
      {
        path:'product/:id/:transactionId', 
        loadChildren : './single-product/single-product.module#SingleProductModule'
      },
      {
        path:'myaccount', 
        loadChildren : './myaccount/myaccount.module#MyAccountModule', canActivate: [AuthGuardService]
      },
      {
        path:'login/:email', 
        loadChildren : './login/login.module#LoginModule'
      },
      {
        path:'login', 
        loadChildren : './login/login.module#LoginModule'
      },
      {
        path:'customer-register', 
        loadChildren : './customer/customer.module#CustomerModule'
      },
      {
        path:'allproducts', 
        loadChildren : './allproducts/allproducts.module#AllProductsModule'
      },
      {
        path:'shopping-cart', 
        loadChildren : './product-cart/product-cart.module#ProductCartModule'
      },
      {
        path:'view-cart',
        loadChildren : './view-cart/view-cart.module#ViewCartModule'
      },
      {
        path:'check-out',
        loadChildren : './check-out/check-out.module#CheckOutModule'
      },
      {
        path:'faq',
        loadChildren : './faq/faq.module#FaqModule'
      },
      {
        path:'terms',
        loadChildren : './terms/terms.module#TermsModule'
      },
      {
        path:'About Us',
        loadChildren : './aboutus/aboutus.module#AboutusModule'
      },
      {
        path:'Contact Us',
        loadChildren : './contactus/contactus.module#ContactusModule'
      },
      {
        path:'wishlist',
        loadChildren : './view-wishlist/view-wishlist.module#ViewWishlistModule'
      },
      {
        path:'forgot-password/:requestType',
        loadChildren : './forgot-password/forgot-password.module#ForgotPasswordModule'
      },
      {
        path:'forgot-username/:requestType',
        loadChildren : './forgot-username/forgot-username.module#ForgotUsernameModule'
      },
      {
        path:'order-summery',
        loadChildren : './order-summery/order-summery.module#OrderSummeryModule'
      },
      {
        path:'categories',
        component : BlogcategoryComponent,canActivate: [AuthGuardService]
      },
      {
        path:'blogs',
        component : BlogComponent,canActivate: [AuthGuardService]
      },
      {
        path:'blog-posts',
        component : BlogFeComponent
      },
      {
        path:'blog-posts/:id',
        component : BlogFeComponent
      },
      {
        path:'blog-detail-posts/:id',
        component : BlogDetailComponent
      }
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers:[AuthGuardService]
})

export class AppRoutingModule { }
