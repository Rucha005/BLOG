import { Component, OnInit } from '@angular/core';
import { BlogService } from '../blog.service';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from '../../environments/environment';

@Component({
  selector: 'app-blog-detail',
  templateUrl: './blog-detail.component.html',
  styleUrls: ['./blog-detail.component.css']
})
export class BlogDetailComponent implements OnInit {
  getBlogDataValues: any;
  blogid: any;
  getCategoryDataValues: any;
  getFeatureDataValues: any;

  public repoUrl = window.location.href;
  public imageUrl;
  imageurl: string;
  description: any;

  constructor(private blogService: BlogService,private route: ActivatedRoute,private router: Router) {
    route.params.subscribe(val => 
      {
        this.blogid = val.id;
      });  
   }

  ngOnInit() {
    this.imageurl = environment.blogip + '/';
    this.getBlogData();
    this.getCategoryData();
    this.getFeatureData();
  }

  getBlogData(){
    this.blogService.getBlogDataById(this.blogid)
    .subscribe(items => {
      this.getBlogDataValues = items;
      this.getBlogDataValues = this.getBlogDataValues[0];
      this.imageUrl = this.getBlogDataValues.image;
      this.description = this.getBlogDataValues.description
      //console.log(JSON.stringify(this.getBlogDataValues))
    },(error)=>{
    }); 
  } 
  getCategoryData(){
    this.blogService.getAllCategoryData()
    .subscribe(items => {
      this.getCategoryDataValues = items;
      //console.log(JSON.stringify(this.getCategoryDataValues))
    },(error)=>{
    }); 
  }
  navigatetoblog(categoryid){
    this.router.navigate(['/blog-posts/',categoryid])
  }
  getFeatureData(){
    this.blogService.getFeatureData(this.blogid)
    .subscribe(items => {
      this.getFeatureDataValues = items;
     // console.log(JSON.stringify(this.getFeatureDataValues))
    },(error)=>{
    });
  }
  navigatetoblogdetails(blogid){
    this.router.navigate(['/blog-detail-posts/',blogid])
    location.reload();
  }

}



export declare class FacebookParams {
  url: string;
}

export class GooglePlusParams {
  url: string
}

export class LinkedinParams {
  url:string
}

export declare class PinterestParams {
  url: string;
  media: string;
  description: string;
}

export class TwitterParams {
  text: string;
  url: string;
  hashtags: string;
  via: string;
}