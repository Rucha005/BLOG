import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { BlogAllServices } from './blogallservice.service';
import { HttpRequest, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable()
export class BlogService {

  constructor(private http: Http) { }

  //Get all categories data
  getAllCategoryData() {
    return this.http.get(BlogAllServices.getAllCategoryData)
      .map((response: Response) => response.json());
  }

  //Create New Category 
  addNewCategory(data) {
    return this.http.post(BlogAllServices.addNewCategory, data)
      .map((response: Response) => response.json());
  }

  //delete category
  deleteCategory(categoryid) {
    return this.http.delete(BlogAllServices.removeCategory + '/' + categoryid)
      .map((response: Response) => response.json());
  }

  //update category
  updateCategory(categoryid, data) {
    return this.http.put(BlogAllServices.updateCategory + '/' + categoryid, data)
      .map((response: Response) => response.json());
  }


  //get all blogs data
  getAllBlogData() {
    return this.http.get(BlogAllServices.getAllBlogData)
      .map((response: Response) => response.json());
  }

  //create new blog 
  addNewBlog(data) {
    return this.http.post(BlogAllServices.addNewBlog, data)
      .map((response: Response) => response.json());
  }

  //delete blog
  deleteBlog(blogid) {
    return this.http.delete(BlogAllServices.removeBlog + '/' + blogid)
      .map((response: Response) => response.json());
  }

  //update blog
  updateBlog(blogid, data) {
    return this.http.put(BlogAllServices.updateBlog + '/' + blogid, data)
      .map((response: Response) => response.json());
  }

  //get blogid wise data
  getBlogDataById(blogid){
    return this.http.get(BlogAllServices.getBlogDataById + '/' + blogid)
      .map((response: Response) => response.json());
  }

  //get categoryname
  getCategoryName(categoryid){
    return this.http.get(BlogAllServices.getCategoryName + '/' + categoryid)
      .map((response: Response) => response.json());
  }

   //get category wise blog data
   getCategoryData(categoryid){
    return this.http.get(BlogAllServices.getCategoryData + '/' + categoryid)
      .map((response: Response) => response.json());
  }

  //get feature data of blogs
  getFeatureData(blogid){
    return this.http.get(BlogAllServices.getFeatureData + '/' + blogid)
     .map((response: Response) => response.json());
  }

  //get feature data of blogs
  checkCategoryExist(categoryname){
    return this.http.get(BlogAllServices.checkCategoryExist + '/' + categoryname)
     .map((response: Response) => response.json());
  }
}