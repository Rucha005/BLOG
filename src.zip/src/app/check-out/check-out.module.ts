import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CheckOutRoutingModule } from './check-out-routing.module';
import { CheckOutComponent } from './check-out/check-out.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { LoginService } from '../login/login/login.service';
import { ProductCartService } from '../common/product-cart.service';
import { ProductService } from '../common/product.service';
import { RegistartionService } from '../common/registartion.service';
import { AddressService } from '../common/address.service';

@NgModule({
  imports: [
    CommonModule,
    CheckOutRoutingModule, ReactiveFormsModule, FormsModule
  ],
  declarations: [CheckOutComponent],
  providers:[LoginService,ProductCartService,ProductService,RegistartionService,AddressService]
})
export class CheckOutModule { }
