export class Options {
  constructor() {}
    public key: string;
    public txnid: string;
    public amount: string;
    public productinfo: string;
    public firstname: string;
    public email: string;
    public phone: string;
    public surl: string;
    public furl: string;
    public hash: string;
    public service_provider: string;
    public lastname: string;
    public address1: string;
    public address2: string;
    public city: string;
    public state: string;
    public country: string;
    public zipcode: string;
    public udf1: string;
    public udf2: string;
    public udf3: string;
    public udf4: string;
    public udf5: string;
    public udf6: string;
    public udf7: string;
    public udf8: string;
    public udf9: string;
    public udf10: string;
}



