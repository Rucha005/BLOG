export class Levels {
	constructor( public levelOneId: number,
				 public levelOneName :string,
        		 public levelOneDescription : string,
				 public defaultImageLink:string,
				 public displayOrder,
				 public levelTwo: levelTwoData[]
				
       			) { }
} 
export class levelTwoData {
	constructor(
				 public levelTwoId: number,
		         public levelTwoName : string,
		         public levelTwoDescription:  string,
                 public defaultImageLink:  string,
                 public displayOrder:  string,
                 public levelThree: levelThreeData[]
	    
	){}
    
}
export class levelThreeData {
	constructor(
				 public levelThreeId: number,
		         public levelThreeName : string,
		         public levelThreeDescription:  string,
                 public defaultImageLink:  string,
                 public displayOrder:  string,
                 public levelFour: levelFourData[]
	    
	){}
    
}
export class levelFourData {
	constructor(
				 public levelFourId: number,
		         public levelFourName : string,
		         public levelFourDescription:  string,
                 public defaultImageLink:  string,
                 public displayOrder:  string,
                
	    
	){}
    
}