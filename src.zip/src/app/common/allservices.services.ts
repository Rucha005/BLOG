import { environment } from '../../environments/environment';
import { Injectable } from '@angular/core';

@Injectable()
export class AllServices 
{
    static servicecalled: boolean;
    constructor(){}

    static ip = environment.ip;
    
    /** menus or all level data */
    static getLevelOneAllUrl = AllServices.ip + "/levelOne/fetchAll";
    static getLevelTwoAllUrl = AllServices.ip + "/levelTwo/fetchAll";
    static getLevelThreeAllUrl = AllServices.ip + "/levelThree/fetchAll";
    static getLevelFourAllUrl = AllServices.ip + "/levelFour/fetchAll";    
    static getLevelTwoAllByIdUrl = AllServices.ip + "/levelTwo/fetchByLevelOneId";
    static getLevelThreeAllByIdUrl = AllServices.ip + "/levelThree/fetchByLevelTwoId";
    static getLevelFourAllByIdUrl = AllServices.ip + "/levelFour/fetchByLevelThreeId";
    static  allLevelUrl = AllServices.ip + '/level/levelOne/fetchAll';
    
    /** Product Browser Page */
   
    /** Get Product Data with Sorting (asc or desc) - product browser */
    static loadLevelItemDataUrl = AllServices.ip + '/assignLevelToModel';
    /** get all filter data (product browser) */
    static allProductfilterDataUrl = AllServices.ip + '/filter/';
    /** get products data by selected filter values*/
    static onSelectfilterDataUrl = AllServices.ip + '/modelDetails/fetchRentableModelsByFilter';

    /*Breadcrumb for product browswe and product details */
    static levelOnebreadcrumburl =AllServices.ip+"/modelDetails/levelOne/fetchBreadCrumbForBrowser";
    static levelTwobreadcrumburl =AllServices.ip+"/modelDetails/levelTwo/fetchBreadCrumbForBrowser";
    static levelThreebreadcrumburl =AllServices.ip+"/modelDetails/levelThree/fetchBreadCrumbForBrowser";
    static levelFourbreadcrumburl =AllServices.ip+"/modelDetails/levelFour/fetchBreadCrumbForBrowser";
    
    /** Product Details Page */
  
    /** get products details by model id (product details) */
    static getProductDetailsByIdUrl = AllServices.ip + '/modelDetails/fetchRentableModelDetailsByModelId';
    /** get all product filters and specifications (product details) */
    static getModelFilterByIdUrl = AllServices.ip + '/modelDetails/fetchFilterDetailsOfRentableModel';
    /** get products images - thumbnail and others */
    static getAllProductImagesUrl = AllServices.ip+"/model/fetchModelImagesBySize";
    /** if any offer then get all offers data */
    static loadOfferDataUrl = AllServices.ip+"/modelDetails/fetchOffersByTransactionId";
    /** check product is available on selected date and get quantity and cash (days) discount */
    static getDiscountandStockonBookingValues= AllServices.ip+"/modelDetails/checkIfProductIsAvailable"; 
    /*related product */
    static relatedproductsburl =AllServices.ip+"/assignLevelToModel/fetchRelatedProducts";
    
    /** Customer registration */
   
    static createCustomer= AllServices.ip+"/user/create/customer";
    /** get user data */
    static getUserName= AllServices.ip+"/user/username";
    /** check user exist or not */
    static isUserExits = AllServices.ip+"/user/isUserExists";
    static isMobileExits = AllServices.ip+"/user/checkUserExistedbyMobileNumber";
    /** login via otp */
    static getloginotp =AllServices.ip+"/user/login/otp"; 
    static loginviaotp = AllServices.ip+"/user/verify/login/otp";


    /** home page */
  
    /** Display latest / feature products home page */
    static allFeatureProductData = AllServices.ip + '/modelDetails/fetchRentableFeatureProducts';
    /** Display collection products home page */
    static allCollectionData = AllServices.ip + '/modelDetails/fetchCollectionWiseModels';
    /* get all product services */
    static allproductsurl=AllServices.ip+"/assignLevelToModel/fetchAllRentableProducts" 
    
    /*Rent Cart Service - View Cart Page */
  
    /** add local cart data into database */
    //addCartDataToDatabaseUrl = AllServices.ip+"/rentCart/addToCart";
    static addCartDataToDatabaseUrl = AllServices.ip+"/rentCart/addToCartOrWishlist";
    /** get all cart data for pericular customer */
    static loadAllCartDataByCustomerIdUrl= AllServices.ip+"/rentCart/fetchAllCartItemsByUserId";
    static loadAllWishlistDataByCustomerIdUrl= AllServices.ip+"/rentCart/fetchAllWishlistItemsByUserId";
    //loadAllCartDataByCustomerIdUrl= AllServices.ip+"/rentCart/fetchAllCartOrWishlistItemsByUserId";
    /** delete cart data from db */
    //removeCartFromDatabaseUrl = AllServices.ip+"/rentCart/removeFromCart";
    static removeCartFromDatabaseUrl = AllServices.ip+"/rentCart/removeFromCartOrWishlist";
    static removeWishlistFromDatabaseUrl =AllServices.ip+"/rentCart/removeWishlistProduct";
    /** increase / decrease quantity for cart products */
    static addOrRemoveQuantityInDatabaseUrl = AllServices.ip+"/rentCart/changeItemQuantity";
    /** get cart count */
    //cartItemCountUrl= AllServices.ip+"/rentCart/fetchCartItemCountByUserId";
    static cartItemCountUrl= AllServices.ip+"/rentCart/fetchCartOrWishlistItemCountByUserId";
    /**move data / product cart to wishlist or vise a versa */
    static moveDataToWishlistOrCart = AllServices.ip+"/rentCart/moveToWishlistOrCart/";
    /** send mail for coming soon product */
    static sendmailComingSoonProduct = AllServices.ip+"/modelDetails/sendMailForComingSoonProduct/"; 

    /*Order Summery Service - Checkout Page */
  
    /** check coupon code valid or not */
    static couponCodeUrl =AllServices.ip+"/rentOrder/validateCoupon"
    /** load user address if any */
    static loadCartUserAddressUrl = AllServices.ip+"/user/fetchAddressByUserId";
    /** create new address for customer */
    static createAddress =AllServices.ip+"/user/addOrEditAddress";
    /** delete address for customer */
    static deleteAddress =AllServices.ip+"/user/deleteUserAddress";
    //http://192.168.0.232:9091/user/deleteUserAddress?id=65
    /** check user document verification status */
    static checkUserDocumentVerification = AllServices.ip+"/user/verificationStatus";
    /**update legal documents for users */
    static updateUserLegalDoc =  AllServices.ip+"/user/uploadCustomerDocument";
    /** get all product data of customer */
    static loadAllOrderDataByCustomerIdUrl = AllServices.ip+"/rentOrder/fetchOrderSummaryByUserId";
    /** delete product from checkout page */
    static removePlaceOrderedDataFromCartUrl=AllServices.ip+"/rentOrder/deleteCartByOrderId";
    /** place order */
    static placeOrderUrl = AllServices.ip+"/rentOrder/placeOrder";
    /** generate hash code*/
    static paymentHashUrl = AllServices.ip+"/generateHash";
    /** redirect to payumoney */
    static paymenturl = "https://secure.payu.in/_payment";

    /** My account Page */
  
    /** get all orders data (summery) */
    static loadPlaceOrderItemsByCustomerIdUrl = AllServices.ip+"/rentOrder/fetchOrderSummaryByCustomerId";
    /** get order details by id */
    static viewOrderByOrderIdUrl =  AllServices.ip+"/rentOrder/fetchById";
    /** cancel order */
    static cancelOrderUrl =AllServices.ip+"/rentOrder/cancelOrder";
    /** Add review from my account */
    static createReview = AllServices.ip+"/reviews/create";
    /** get review by customer */
    static getReviewByCustomer = AllServices.ip+"/reviews/customerReviews";
    /** get review by product */
    static getReviewByProduct =  AllServices.ip+"/reviews/productReviews";
    /** edit contact info for user */
    static editContactInfo = AllServices.ip+"/user/updateUserContactInfo"; 
    
    /** contact us mail sending */
    static sendmailContactUs = AllServices.ip+"/contactUs/notify"; 
   
    /** Order summery data BE */
    static displayOrdersSelectingDates = AllServices.ip+"/rentOrder/fetchSellerOrders"; 
    static displayAllOrders = AllServices.ip+"/rentOrder/fetchSellerOrders"; 
} 