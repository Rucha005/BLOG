import { AllServices } from './allservices.services';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { error } from 'selenium-webdriver';
import { AppError} from './app-error';
import 'rxjs/add/operator/catch';
import { HttpHeaders } from '@angular/common/http';


@Injectable()
export class BreadcrumbService {
  public levelId : number;
  collectionName : string; 
  constructor( private http:Http,) { }
  //Get level One bradcrumb - Product Browser
  getLevelOneBreadcrumb(id) {
    return this.http.get( AllServices.levelOnebreadcrumburl+'?id='+id).map(res => res.json());
  } 
  //Get level Two bradcrumb - Product Browser
  getLevelTwoBreadcrumb(id){
    return this.http.get( AllServices.levelTwobreadcrumburl+'?id='+id).map(res => res.json());
  }
  //Get level Three bradcrumb - Product Browser
  levelThreebreadcrumburl(id){
    return this.http.get( AllServices.levelThreebreadcrumburl+'?id='+id).map(res => res.json());
  }
  //Get level Four bradcrumb - Product Browser
  getLevelFourBreadcrumb(id) {
    return this.http.get( AllServices.levelFourbreadcrumburl+'?id='+id).map(res => res.json());
  }
}