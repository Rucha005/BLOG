import { AllServices } from './allservices.services';
import { Injectable } from '@angular/core';
import { Http,  Headers,RequestOptions,Response } from '@angular/http';
import { LoginService } from '../login/login/login.service';


@Injectable()
export class MyOrderService {
  customerId:number;
  productId:number;
  rentOrderId:number;
  orderItemsIndex:number;

  constructor(private http:Http,  private loginService:LoginService) { }

  loadPlaceOrderItemsByCustomerId(id){
     let headers = new Headers({
        'authorization': 'Bearer' + this.loginService.getToken(),
        'content-type': 'application/json'
      });

      let options = new RequestOptions({headers: headers});
      return this.http.get( AllServices.loadPlaceOrderItemsByCustomerIdUrl+"?id="+id , options).map(res => res.json());  
  }  
  viewOrderByOrderId(rentOrderId){
    let headers = new Headers({
        'authorization': 'Bearer' + this.loginService.getToken(),
        'content-type': 'application/json'
      });   
     let options = new RequestOptions({headers: headers});
      return this.http.get( AllServices.viewOrderByOrderIdUrl+"?id="+rentOrderId , options).map(res => res.json());  
  }
  getCancelrentOrderId(){
    return this.rentOrderId;
  }
  getCancelorderItemsIndex(){
    return this.orderItemsIndex;
  }
  setCanceldetails(rentOrderId,orderItemsIndex){
    this.rentOrderId = rentOrderId;
    this.orderItemsIndex= orderItemsIndex;
  }
  editContactInfo(data){
    let headers = new Headers({
      'authorization': 'Bearer' + this.loginService.getToken(),
      'content-type': 'application/json'
    });  
    let options = new RequestOptions({headers: headers});
      return this.http.post( AllServices.editContactInfo ,data,options 
      ).map((response: Response) =>  response.json());
  }
  cancelOrder(data){
    let headers = new Headers({
      'authorization': 'Bearer' + this.loginService.getToken(),
      'content-type': 'application/json'
    });
    let options = new RequestOptions({headers: headers});
    return this.http.post( AllServices.cancelOrderUrl, data, options).map(res => res.json()); 
  } 
}