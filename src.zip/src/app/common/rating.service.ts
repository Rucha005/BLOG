import { AllServices } from './allservices.services';
import { Injectable } from '@angular/core';
import { Http,  Headers,RequestOptions,Response } from '@angular/http';
import { LoginService } from '../login/login/login.service';


@Injectable()
export class RatingService {
  customerId:number;
  productId:number;
  rentOrderId:number;
  orderItemsIndex:number;

  constructor(private http:Http,  private loginService:LoginService) { }
  
  getReviewproductId(){
    return this.productId;
  }
  getReviewcustomerId(){
    return this.customerId;
  }
  getReviewrentOrderId(){
    return this.rentOrderId;
  }
  setReviewdetails(productid,customerid,rentOrderId){
     this.productId = productid;
     this.customerId= customerid;
     this.rentOrderId = rentOrderId;
  }
  ReviewProduct(data){
    let headers = new Headers({
      'authorization': 'Bearer' + this.loginService.getToken(),
      'content-type': 'application/json'
    });  
    let options = new RequestOptions({headers: headers});
      return this.http.post( AllServices.createReview, data ,options 
      ).map((response: Response) =>  response.json());
  }
  // get review data by customer id
  getReviewByCustomer(userid){
    let headers = new Headers({
      'authorization': 'Bearer' + this.loginService.getToken(),
      'content-type': 'application/json'
    });  
    let options = new RequestOptions({headers: headers});
      return this.http.get( AllServices.getReviewByCustomer+'?id='+userid,options 
      ).map((response: Response) =>  response.json());
  }
  // get product wise reviews
  getReviewByProduct(productId){
    return this.http.get( AllServices.getReviewByProduct+'?id='+productId
    ).map((response: Response) =>  response.json());
  }
}