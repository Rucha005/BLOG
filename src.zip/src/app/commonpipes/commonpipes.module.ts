import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CommonpipesRoutingModule } from './commonpipes-routing.module';

@NgModule({
  imports: [
    CommonModule,
    CommonpipesRoutingModule,
  ],
  declarations: [],
  exports:[]
})
export class CommonpipesModule { }
