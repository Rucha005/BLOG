import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { error } from 'selenium-webdriver';
import 'rxjs/add/operator/catch';
import { HttpHeaders } from '@angular/common/http';
import { AllServices } from '../../common/allservices.services';


@Injectable()
export class ContactUsService {
  
  constructor(private http:Http) { }
 
  //mailsending for contact page
  sendmailContactUs(data) 
  {
    return this.http.post( AllServices.sendmailContactUs, data).map(res => res.json());
  } 

  //send mail for comingsoon product
  sendmailForComingSoonProduct(data,modelId)
  {
    return this.http.post( AllServices.sendmailComingSoonProduct+modelId, data).map(res => res.json());
  }
 
}