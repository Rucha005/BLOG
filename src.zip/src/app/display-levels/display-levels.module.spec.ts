import { DisplayLevelsModule } from './display-levels.module';

describe('DisplayLevelsModule', () => {
  let displayLevelsModule: DisplayLevelsModule;

  beforeEach(() => {
    displayLevelsModule = new DisplayLevelsModule();
  });

  it('should create an instance', () => {
    expect(displayLevelsModule).toBeTruthy();
  });
});
