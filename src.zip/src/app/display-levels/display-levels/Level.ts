export class Level {
  constructor(public id: number, public name: string) { }
}

