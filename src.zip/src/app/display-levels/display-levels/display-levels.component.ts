import { LOCAL_STORAGE, WINDOW } from '@ng-toolkit/universal';
import { Component, OnInit, Output, EventEmitter, ViewChild, Input, HostListener, Inject } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators, FormControl, AbstractControl } from '@angular/forms';
import { RouterModule, ActivatedRoute, Router } from '@angular/router';
import { Level } from './Level';
import { Products } from '../../products/products/products';
import { Filter } from '../../products/products/Filter';
import { ErrorStatus } from '../../common/ErrorStatus';
import { Filterdropdown } from '../../products/products/Filterdropdown';
import { LevelOneData } from '../../header/header/allLevel';
import { BreadcrumbService } from '../../common/breadcrumb.service';
import { LevelDataService } from '../../common/levelData.service';
import { LoginService } from '../../login/login/login.service';
import { RegistartionService } from '../../common/registartion.service';
import { ProductCartService } from '../../common/product-cart.service';
import { ProductService } from '../../common/product.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'app-display-levels',
  templateUrl: './display-levels.component.html',
  styleUrls: ['./display-levels.component.css']
})
export class DisplayLevelsComponent implements OnInit {
  categorylevelthreeid(arg0: any): any {
    throw new Error("Method not implemented.");
  }
  showothercat: boolean;
  showother1cat: boolean;
  showother2cat: boolean;
  cartitems: any;
  customerId: any;
  filterProductErrorMessage: string;
  showfiltername: boolean;
  showStyle: boolean;
  selectedItem: any;
  activeclass: boolean;
  levelOneNameForAccessories: any;
  levelOneNameForAdventure: any;
  levelOneNameForLuggage: any;
  levelOneNameForLevelFour: any;
  levelThreebreadcrumb: any;
  servicecalled: boolean;
  decrementcounter: number = 0;
  incrementcounter: number = 0;
  levelFourDataRiding: any;
  levelFourDataCamera: any;
  levelThreeDataRiding: any;
  items: Products[] = [];
  allFilterData: Filter[] = [];
  allcontrols: HTMLInputElement[] = [null];
  errorStatus: ErrorStatus;
  id: number;
  name: string;
  filterDrop: Filterdropdown[] = [];
  filterText: Filterdropdown[] = [];
  selectedSortingValue: number;
  _Filterform: FormArray;
  pagedItems: Products[] = [];
  levelOneData: any[];
  levelFourData: any[];
  levelThreeData: any[];
  levelTwoData: any[];
  categoryleveloneid: any;
  levelOneId: any;
  levelOneBreadcrumb: LevelOneData;
  levelTwobreadcrumb: LevelOneData;
  levelFourBreadcrumb: LevelOneData;
  ShowFilterSelected: boolean;
  productErrorMessage = null;
  sortLevel = [
    new Level(1, 'Low To High'),
    new Level(2, 'High To Low'),
  ];
  constructor(@Inject(WINDOW) private window: Window, @Inject(LOCAL_STORAGE) private localStorage: any,
              private productService: ProductService,private cartService: ProductCartService,
              private route: ActivatedRoute, private router: Router, private fb: FormBuilder, 
              private registrationservice: RegistartionService, private breadcrumbService: BreadcrumbService,
              private leveldataservice: LevelDataService, private loginService: LoginService, 
              private spinnerService: Ng4LoadingSpinnerService) 
  {
    this.selectedSortingValue = 1;
    this.id = null;
    this.name = null;
    this.levelFourBreadcrumb = null;
    this.levelOneBreadcrumb = null;
    this.levelTwobreadcrumb = null;
    this.levelFourData = null;
    this.productErrorMessage = null;
    this.filterProductErrorMessage = null;
    this._Filterform = this.fb.array([]);

    this.spinnerService.show();
    route.params.subscribe(val => 
    {
      this.spinnerService.hide();
      this.productErrorMessage = null;
      this.items = null;
      this.pagedItems = null;
      this.allFilterData = null;
      if (this.filterDrop.length > 0) 
      {
        for (let s = 0; s < this.filterDrop.length; s++) 
        {
          this.filterDrop.splice(s);
        }
      }
      if (this.filterText.length > 0) 
      {
        for (let r = 0; r < this.filterText.length; r++) 
        {
          this.filterText.splice(r);
        }
      }
      if (val.name) 
      {
        this.id = val.id;
        this.name = val.name;
        if (this.loginService.isLoggedIn()) 
        {
          this.getByUsername();
        } 
        else 
        {
          this.loadAllDataInAscWithoutLogin();
        }
        for (let z = 0; z < this._Filterform.length; z++) 
        {
          this._Filterform.removeAt(z);
        }
        this.allProductfilterData();
        this.breadCrumb();
        this.getothercategories();
      }
    }, 
    (error) => 
    {
      this.spinnerService.hide();
    });
    this.productErrorMessage = null;
  }
  
  /** breadCrumb - for all level data */
  breadCrumb() 
  {
    this.levelFourBreadcrumb = null;
    this.levelOneBreadcrumb = null;
    this.levelTwobreadcrumb = null;
    this.levelThreebreadcrumb = null;
    
    if (this.name === 'levelFour') 
    {
      this.spinnerService.show();
      this.breadcrumbService.getLevelFourBreadcrumb(this.id).subscribe(s => 
      {
        this.spinnerService.hide();
        this.levelFourBreadcrumb = s;
        this.levelOneId = this.levelFourBreadcrumb.levelOneId;
        this.localStorage.setItem('levelOne', this.levelOneId.toString());
        this.localStorage.setItem('levelFour', this.id.toString());
      }, 
      (error) => 
      {
        this.spinnerService.hide();
        this.errorStatus = JSON.parse(error._body);
      });
    } 
    else if (this.name === 'levelOne') 
    {
      this.spinnerService.show();
      this.breadcrumbService.getLevelOneBreadcrumb(this.id).subscribe(s => 
      {
        this.spinnerService.hide();
        this.levelOneBreadcrumb = s;
        this.localStorage.setItem('levelFour', this.id.toString());
      }, 
      (error) => 
      {
        this.spinnerService.hide();
        this.errorStatus = JSON.parse(error._body);
      });
    } 
    else if (this.name === 'levelTwo') 
    {
      this.spinnerService.show();
      this.breadcrumbService.getLevelTwoBreadcrumb(this.id).subscribe(s => 
      {
        this.spinnerService.hide();
        this.levelTwobreadcrumb = s;
      }, 
      (error) => 
      {
        this.spinnerService.hide();
      })
    } 
    else if (this.name === 'levelThree') 
    {
      this.spinnerService.show();
      this.breadcrumbService.levelThreebreadcrumburl(this.id).subscribe(s => 
      {
        this.spinnerService.hide();
        this.levelThreebreadcrumb = s;
      }, 
      (error) => 
      {
        this.spinnerService.hide();
      })
    }
  }

  /** navigate to details page */
  navigate(event, modelId, rentTransactionId) 
  {
    this.router.navigate(['/product/', modelId, rentTransactionId]);
    event.preventDefault();
    event.stopPropagation();
  }

  ngOnInit() { }
  
  /** initialize fillter form */
  initFilter(id, fValue) 
  {
    return this.fb.group({
      'filterId': [id, Validators.required],
      'value': this.fb.array([this.fb.control(fValue)])
    });
  }

  /** check box on change get filter value */
  onChange(fId: number, fValue: string, isChecked: boolean, control: HTMLInputElement) 
  {
    this.productErrorMessage = null;
    let flag = false;
    if (isChecked) 
    {
      this.allcontrols.push(control);
      // if form is empty
      if (this._Filterform.length === 0) 
      {
        this._Filterform.push(this.initFilter(fId, fValue));
      } 
      else 
      {
        // If User Select Only Filter Value
        for (let z = 0; z < this._Filterform.length; z++) 
        {
          if ((<FormGroup>this._Filterform.at(z)).controls['filterId'].value === fId) 
          {
            flag = true;
            (<FormArray>(<FormGroup>this._Filterform.at(z)).controls['value']).push(this.fb.control(fValue));
            break;
          }
        }
        if (!flag) 
        {
          this._Filterform.push(this.initFilter(fId, fValue));
        }
      }
      // Load All Filter  Form Data
      if (this.selectedSortingValue === 1) 
      {
        this.loadFilterProductInAsc();
      } 
      else if (this.selectedSortingValue === 2) 
      {
        this.loadFilterProductInDesc();
      }
      else{
        this.loadFilterProductInDesc();
      }
    } 
    else 
    {
      this.productErrorMessage = null;
      for (let z = 0; z < this._Filterform.length; z++) 
      {
        const filterIdControl = (<FormGroup>this._Filterform.at(z)).controls['filterId'];
        // check selected filter Id and form id
        if (filterIdControl.value === fId) 
        {
          const filterValueControl = (<FormArray>(<FormGroup>this._Filterform.at(z)).controls['value']);
          for (let a = 0; a < filterValueControl.length; a++) 
          {
            let formValue: string;
            formValue = (<FormArray>(<FormGroup>this._Filterform.at(z)).controls['value']).at(a).value;
            if (formValue.includes(fValue)) 
            {
              (<FormArray>(<FormGroup>this._Filterform.at(z)).controls['value']).removeAt(a);
              if ((<FormArray>(<FormGroup>this._Filterform.at(z)).controls['value']).length === 0) 
              {
                this._Filterform.removeAt(z);
                if (this._Filterform.length > 0) 
                {
                  this.loadFilterProductInAsc();
                } 
                else if (this._Filterform.length === 0) 
                {
                  this.loadAllDataInAscWithoutLogin();
                }
              } 
              else 
              {
                this.loadFilterProductInAsc();
              }
              if (this._Filterform.length === 0) 
              {
                this.loadAllDataInAscWithoutLogin();
              }
            }
          }
        }
      }
    }
  }

  /** clear all filter valued  which are selected */
  onClearFilter() 
  {
    this.productErrorMessage = null;
    this.filterProductErrorMessage = null;
    const fId = 0;
    let lclcontrol: HTMLInputElement;
    while (lclcontrol = this.allcontrols.pop()) 
    {
      lclcontrol.checked = false;
    }
    for (let z = 0; z < this._Filterform.length; z++) 
    {
      this._Filterform.removeAt(z);
      this.loadAllDataInAscWithoutLogin();
    }
  }

  /** display filter data in asc */
  loadFilterProductInAsc() 
  {
    this.productErrorMessage = null;
    this.filterProductErrorMessage = null;
    if (this.customerId > 0) 
    {
      this.productErrorMessage = null;
      this.filterProductErrorMessage = null;
      this.items = null;
      this.pagedItems = null;
      console.log("filter value: " + JSON.stringify(this._Filterform.value));
      this.spinnerService.show();
      this.productService.onSelectfilterData(this._Filterform.value, 'asc', this.customerId).subscribe(s => 
      {
        this.spinnerService.hide();
        this.pagedItems = s;
      }, 
      (error) => 
      {
        this.spinnerService.hide();
        this.filterProductErrorMessage = 'Sorry No Products Found';
        this.pagedItems = null;
      });
    }
    else 
    {
      this.productErrorMessage = null;
      this.filterProductErrorMessage = null;
      this.items = null;
      this.pagedItems = null;
    
      console.log("filter value: " + JSON.stringify(this._Filterform.value));
      this.spinnerService.show();
      this.productService.onSelectfilterData(this._Filterform.value, 'asc', 0).subscribe(s => 
      {
        this.spinnerService.hide();
        this.pagedItems = s;
        this.cartitems = this.cartService.loadAllCartFromLocalStorage();
        for (let p = 0; p < this.pagedItems.length; p++) 
        {
          if (this.cartitems) 
          {
            for (let product = 0; product < this.cartitems.length; product++) 
            {
              if (this.cartitems[product].modelId == this.pagedItems[p].modelId) 
              {
                this.pagedItems[p].cartType = this.cartitems[product].cartType;
                this.pagedItems[p].rentTransactionId = this.cartitems[product].rentTransactionId;
              }
            }
          }
        }
      }, 
      (error) => 
      {
        this.spinnerService.hide();
        this.filterProductErrorMessage = 'Sorry No Products Found';
        this.pagedItems = null;
      });
    }
  }

  /** display filter data in desc */
  loadFilterProductInDesc() 
  {
    this.productErrorMessage = null;
    this.filterProductErrorMessage = null;
    if (this.customerId > 0) 
    {
      this.productErrorMessage = null;
      this.filterProductErrorMessage = null;
      this.items = null;
      this.pagedItems = null;
    
      console.log("filter value: " + JSON.stringify(this._Filterform.value));
      this.spinnerService.show();
      this.productService.onSelectfilterData(this._Filterform.value, 'desc', this.customerId).subscribe(s => 
      {
        this.spinnerService.hide();
        this.pagedItems = s;
      }, 
      (error) => 
      {
        this.spinnerService.hide();
        this.filterProductErrorMessage = 'Sorry No Products Found';
        this.pagedItems = null;
      });
    }
    else 
    {
      this.productErrorMessage = null;
      this.filterProductErrorMessage = null;
      this.items = null;
      this.pagedItems = null;
      console.log("filter value: " + JSON.stringify(this._Filterform.value));
      this.spinnerService.show();
      this.productService.onSelectfilterData(this._Filterform.value, 'desc', 0).subscribe(s => 
      {
        this.spinnerService.hide();
        this.pagedItems = s;
        this.cartitems = this.cartService.loadAllCartFromLocalStorage();
        for (let p = 0; p < this.pagedItems.length; p++) 
        {
          if (this.cartitems) 
          {
            for (let product = 0; product < this.cartitems.length; product++) 
            {
              if (this.cartitems[product].modelId == this.pagedItems[p].modelId) 
              {
                this.pagedItems[p].cartType = this.cartitems[product].cartType;
              }
            }
          }
        }
      }, 
      (error) => 
      {
        this.spinnerService.hide();
        this.filterProductErrorMessage = 'Sorry No Products Found';
        this.pagedItems = null;
      });
    }
  }

  /** get customer name after login */
  getByUsername() 
  {
    if (this.localStorage.getItem('currentUser')) 
    {
      const currentUser = JSON.parse(this.localStorage.getItem('currentUser'));
      if (currentUser) 
      {
        this.spinnerService.show();
        this.registrationservice.getByUsername(currentUser.username)
        .subscribe(c => 
        {
          this.spinnerService.hide();
          this.customerId = c.userId
          this.loadAllDataInAsc();
        },
        (error) => 
        {
          this.spinnerService.hide();
        });
      }
    }
  }

   /** display all data in asc */
   loadAllDataInAsc() 
   {
     this.productErrorMessage = null;
     this.filterProductErrorMessage = null;
     this.selectedSortingValue = 1;
     this.items = null;
     this.pagedItems = null;
   
     if (this.loginService.isLoggedIn()) 
     {
       this.spinnerService.show();
       this.productService.loadLevelItemData(this.id, this.name, 'asc', this.customerId).subscribe(items => 
       {
         this.spinnerService.hide();
         this.pagedItems = items;
       },
       (error) => 
       {
         this.spinnerService.hide();
         this.productErrorMessage = 'Sorry No Products Found';
         this.pagedItems = null;
       });
     }
     else 
     {
       this.loadAllDataInAscWithoutLogin()
     }
   }
   loadAllDataInAscWithoutLogin() 
   {
    this.productErrorMessage = null;
    this.filterProductErrorMessage = null;
     this.spinnerService.show();
     this.productService.loadLevelItemData(this.id, this.name, 'asc', 0).subscribe(items =>
     {
       this.spinnerService.hide();
       this.pagedItems = items;
       this.cartitems = this.cartService.loadAllCartFromLocalStorage();
       for (let p = 0; p < this.pagedItems.length; p++) 
       {
         if (this.cartitems) 
         {
           for (let product = 0; product < this.cartitems.length; product++) 
           {
             if (this.cartitems[product].modelId == this.pagedItems[p].modelId) 
             {
               this.pagedItems[p].cartType = this.cartitems[product].cartType;
             }
           }
         }
       }
     }, 
     (error) => 
     {
       this.spinnerService.hide();
       this.productErrorMessage = 'Sorry No Products Found';
       this.pagedItems = null;
     });
   }

  /** display all data in desc */
  loadAllDataInDesc() 
  {
    this.productErrorMessage = null;
    this.filterProductErrorMessage = null;
    this.selectedSortingValue = 1;
    this.items = null;
    this.pagedItems = null;
    if (this.loginService.isLoggedIn()) 
    {
      this.getByUsername();
      this.spinnerService.show();
      this.productService.loadLevelItemData(this.id, this.name, 'desc', this.customerId).subscribe(items => 
      {
        this.spinnerService.hide();
        this.pagedItems = items;
      }, 
      (error) => 
      {
        this.spinnerService.hide();
        this.productErrorMessage = 'Sorry No Products Found';
        this.pagedItems = null;
      });
    }
    else 
    {
      this.loadAllDataInDescWithoutLogin()
    }
  }

  loadAllDataInDescWithoutLogin() 
  {
    this.productErrorMessage = null;
    this.filterProductErrorMessage = null; 
    this.spinnerService.show();
    this.productService.loadLevelItemData(this.id, this.name, 'desc', 0).subscribe(items => 
    {
      this.spinnerService.hide();
      this.pagedItems = items;
      this.cartitems = this.cartService.loadAllCartFromLocalStorage();
      for (let p = 0; p < this.pagedItems.length; p++) 
      {
        if (this.cartitems) 
        {
          for (let product = 0; product < this.cartitems.length; product++) 
          {
            if (this.cartitems[product].modelId == this.pagedItems[p].modelId) 
            {
              this.pagedItems[p].cartType = this.cartitems[product].cartType;
            }
          }
        }
      }
    }, 
    (error) => 
    {
      this.spinnerService.hide();
      this.productErrorMessage = 'Sorry No Products Found';
      this.pagedItems = null;
    });
  }

  /** get sorted value(high to low / low to high) and load data */
  sort(value) 
  {
    if (value === '2') 
    {
      if (this._Filterform.length > 0) 
      {
        this.loadFilterProductInDesc();
      } 
      else 
      {
        this.loadAllDataInDescWithoutLogin();
      }
    } 
    else if (value === '1') 
    {
      if (this._Filterform.length > 0) 
      {
        this.loadFilterProductInAsc();
      } 
      else 
      {
          this.loadAllDataInAscWithoutLogin();
      }
    }
  }
  /** display filter data */
  allProductfilterData()
  {
    this.productErrorMessage = null;
    this.filterProductErrorMessage = null;
    this.spinnerService.show();
    this.productService.allProductfilterData(this.id, this.name).subscribe(s => {
      this.spinnerService.hide();
      this.allFilterData = s;
      this.loadFilterData();
    }, (error) => {
      this.spinnerService.hide();
    });
  }
  /** display filter data in checkbox form */
  loadFilterData() 
  {
    let j = 0;
    let k = 0;
    if (this.name === 'levelFour') 
    {
      if (this.id == 9 || this.id == 10 || this.id == 19 || this.id == 20) 
      {
        this.showfiltername = false;
      } 
      else 
      {
        this.showfiltername = true;
        for (let r = 0; r < this.allFilterData.length; r++) 
        {
          if (this.allFilterData[r].filterDisplayType === 'checkbox') 
          {
            const p = this.allFilterData[r].filterContainer.split(',');
            this.filterDrop[j] = new Filterdropdown();
            this.filterDrop[j].filterId = this.allFilterData[r].filterId;
            this.filterDrop[j].filterName = this.allFilterData[r].filterName;
            this.filterDrop[j].filterDisplayType = this.allFilterData[r].filterDisplayType;
            this.filterDrop[j].filterDropdown = p;
            j++;
          } 
          else if (this.allFilterData[r].filterDisplayType === 'text') 
          {
            this.filterText[k] = new Filterdropdown();
            this.filterText[k].filterId = this.allFilterData[r].filterId;
            this.filterText[k].filterName = this.allFilterData[r].filterName;
            this.filterText[k].filterDisplayType = this.allFilterData[r].filterDisplayType;
            k++;
          }
        }
      }
    }
  }
  /* show filter menu in mobile view  */
  ShowFilterButton() 
  {
    this.ShowFilterSelected = true;
  }
  /* hide filter menu in mobile view  */
  HideFilterButton() 
  {
    this.ShowFilterSelected = false;
  }
  /* on scroll show filter menu in mobile view  */
  @HostListener('window:scroll', ['$event'])
  onScroll(event) 
  {
    if (this.pagedItems != null && this.showfiltername != null) 
    {
      const filterdiv = document.getElementById('floatingfillter');
      if (this.window.pageYOffset > 50) 
      {
        filterdiv.classList.add('float');
      } 
      else 
      {
        filterdiv.classList.remove('float');
      }
    }
  }
  /** get under level two - level four categories */
  getothercategories() 
  {
    this.productErrorMessage = null;
    this.filterProductErrorMessage = null;
    this.levelFourBreadcrumb = null; this.levelOneBreadcrumb = null; this.levelTwobreadcrumb = null; this.levelFourData = null; this.levelTwoData = null; this.levelThreeData = null; this.levelFourDataCamera = null; this.levelThreeDataRiding = null; this.levelFourDataRiding = null;
    if ( this.name == 'levelTwo') 
    {
      this.leveldataservice.getLevelThreeAllById(this.id).subscribe(levelThreeItems => 
      {
        this.levelThreeDataRiding = levelThreeItems;
        for (let i = 0; i < this.levelThreeDataRiding.length; i++) 
        {
          if (this.levelThreeDataRiding[i].levelThreeName === 'NOT APPLICABLE') 
          {
            this.leveldataservice.getLevelThreeAllById(this.id).subscribe(levelThreeItems => 
            {
              this.levelThreeData = levelThreeItems;
              for (let j = 0; j < levelThreeItems.length; j++) 
              {
                this.leveldataservice.getLevelFourAllById(levelThreeItems[j].levelThreeId).subscribe(levelFourItems => 
                {
                  this.levelFourData = levelFourItems
                  this.showother2cat = true;
                  this.showothercat = false;
                  this.showother1cat = false;
                })
              }
            })
          }
          else 
          {
            this.levelFourData = levelThreeItems
            this.showothercat = true;
            this.showother1cat = false;
            this.showother2cat = false;
          }
        }
      });
    }
    else if (this.name == 'levelOne') 
    {
      this.leveldataservice.getLevelTwoAllById(this.id).subscribe(levelTwoItems => {
        this.levelTwoData = levelTwoItems;
        for (let i = 0; i < this.levelTwoData.length; i++) 
        {
          //console.log(this.levelTwoData[i].levelTwoName)
          if (this.levelTwoData[i].levelTwoName === 'NOT APPLICABLE') 
          {
            this.leveldataservice.getLevelTwoAllById(this.id).subscribe(levelTwoItems => 
            {
              for (let j = 0; j < levelTwoItems.length; ++j) 
              {
                this.leveldataservice.getLevelThreeAllById(levelTwoItems[j].levelTwoId).subscribe(levelThreeItems => {
                  this.levelThreeData = levelThreeItems;
                  for (let k = 0; k < levelThreeItems.length; ++k) 
                  {
                    this.leveldataservice.getLevelFourAllById(levelThreeItems[k].levelThreeId).subscribe(levelFourItems => {
                      this.levelFourData = levelFourItems;
                      this.showother2cat = true;
                      this.showother1cat = false;
                      this.showothercat = false;
                    })
                  }
                });
              }
            });
          }
          else 
          {
            this.levelFourData = levelTwoItems;
            this.showother2cat = false;
            this.showothercat = false;
            this.showother1cat = true;
          }
        }
      });
    }
    else if (this.name == 'levelFour') 
    {
      this.breadcrumbService.getLevelFourBreadcrumb(this.id).subscribe(s => {
        this.categoryleveloneid = s.levelOneId;
        this.categorylevelthreeid = s.levelThreeId;
          if(s.levelTwoName === 'NOT APPLICABLE')
          {
            this.leveldataservice.getLevelTwoAllById(this.categoryleveloneid).subscribe(levelTwoItems => {
              for (let j = 0; j < levelTwoItems.length; ++j) {
                  this.leveldataservice.getLevelThreeAllById(levelTwoItems[j].levelTwoId).subscribe(levelThreeItems => {
                      for (let k = 0; k < levelThreeItems.length; ++k) {
                          this.leveldataservice.getLevelFourAllById(levelThreeItems[k].levelThreeId).subscribe(levelFourItems => {
                              this.levelFourData = levelFourItems;
                              this.showother2cat = true;
                              this.showothercat = false;
                              this.showother1cat = false;
                          })
                      }
                  });
              }
            });
          }
          else
          {
            this.leveldataservice.getLevelFourAllById(this.categorylevelthreeid).subscribe(levelFourItems => {
                              this.levelFourDataRiding = levelFourItems;
            })
          }
      });
    } 
    else if (this.name == 'levelThree') 
    {
      this.leveldataservice.getLevelFourAllById(this.id).subscribe(levelFourItems => {
        this.levelFourData = levelFourItems;
        this.showother2cat = true;
        this.showother1cat = false;
        this.showothercat = false;
      });
    }
  }
  navigatetodetails(levelfour, levelName, levelId) 
  {
    this.router.navigate(['/productlist/', levelName, levelId]);
    this.showStyle = true;
    this.selectedItem = levelfour;
  }
  getStyle(levelfour) 
  {
    if (levelfour === this.selectedItem) {
      return "red";
    } else {
      return "black";
    }
  }
}
