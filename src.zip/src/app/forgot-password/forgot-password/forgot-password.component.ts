import { PasswordValidators } from './password-validators';
import { ForgotPasswordService } from './forgot-password.service';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { GetOtpResponse } from './get-otp-response';
import { VerifyOTP } from './verify-otp';
import { JwtHelperService} from '@auth0/angular-jwt';
import { environment } from '../../../environments/environment';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})

export class ForgotPasswordComponent implements OnInit
{
  responseForRequestOtp : GetOtpResponse;
  responseForVerifyOtp : VerifyOTP;
  responseForCreateNewPasswordOtp;
  displayFormRequestOtp = "none";
  displayFormVerifyOtp = "none";
  displayFormCreatePassword = "none";
  displayButtonFormVerifyOtpSubmit  = true;
  emailOptionChecked: boolean;
  smsOptionChecked : boolean;
  displayButtonResendOtp  = false;
  formerror = true;  
  incorrectOtp = false;
  userDoesNotExist = false;
  errormessage = null;

  constructor(private fb:FormBuilder, private service : ForgotPasswordService, private route:ActivatedRoute, 
              private spinnerService: Ng4LoadingSpinnerService,private router : Router) 
  {
    if(this.isLoggedIn())
    this.router.navigate(['/home'])
  }
  isLoggedIn() 
  {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (currentUser) 
    {
      let token = currentUser && currentUser.token;
      if (token) 
      {
        let jwtHelper = new JwtHelperService();
        let expirationDate = jwtHelper.getTokenExpirationDate(token);
        let isExpired = jwtHelper.isTokenExpired(token);
        if (isExpired) 
        {
          return false;
        }
        else 
        {
          return true;
        }
      }
    }
    else if(currentUser == null) 
    {
      return false;
    }
  }
  ngOnInit()
  {
    this.route.paramMap.
    subscribe(params=> 
    {
      this.formRequestOtp.controls['requestFor'].setValue(params.get('requestType')); 
      if( this.formRequestOtp.controls['requestFor'].value == "forgotPassword")
      {
          this.displayFormRequestOtp = "block";
          this.displayFormVerifyOtp = "none";
          this.displayFormCreatePassword = "none";
      }
    });
  }
  formRequestOtp = new FormGroup({
    email : new FormControl('',[Validators.email]),
    otpOption : new FormControl,
    requestFor : new FormControl,
    mobileNo : new FormControl('')
  });
  formVerifyOtp = new FormGroup({
    otp : new FormControl('',
      [ 
        Validators.required,
        Validators.minLength(4),
        Validators.maxLength(4),
        Validators.pattern("[0-9]+")
      ]
    ),
    userId : new FormControl
  });
  formCreatePassword = this.fb.group({
    userId : [''],
    password : ['',Validators.required],
    confirmPassword : ['',Validators.required]
  },
  {
    validator : PasswordValidators.passwordsShouldMatch
  });
  onSubmitFormRequestOtp(){
    if (this.formRequestOtp.invalid) 
    {
      return;
    }    
    if( this.smsOptionChecked && this.emailOptionChecked )
    {
      this.formRequestOtp.controls['otpOption'].setValue('both');
    }else
      if( this.smsOptionChecked && !this.emailOptionChecked )
      {
        this.formRequestOtp.controls['otpOption'].setValue('message');
      }
      else
      if( !this.smsOptionChecked && this.emailOptionChecked )
      {
        this.formRequestOtp.controls['otpOption'].setValue('mail');
      }

      this.spinnerService.show();  
      this.service.getOTP(this.formRequestOtp.value)
      .subscribe( response => 
      {
        this.spinnerService.hide();
        this.responseForRequestOtp = response.json();
        this.displayFormRequestOtp = "none";
        this.displayFormVerifyOtp = "block"; 
        this.displayFormCreatePassword = "none";  
        setTimeout(()=>
        { 
          this.displayButtonResendOtp = true; 
          this.displayButtonFormVerifyOtpSubmit  = false;
          this.otp.markAsPristine({onlySelf:true});
          this.otp.disable({onlySelf:true});
          this.incorrectOtp = false;
        }, 1000*60);
      },(error:Response)=>
      {
        this.spinnerService.hide();
        if( error.status === 429 ) // otp already sent
        {
           this.errormessage = "You are already request for otp";
           this.removeErrorMessage() ;
        }
        else if( error.status === 406 )
        {
           this.errormessage = "You have reached maximum limit of  OTP for the day";
          // this.removeErrorMessage(); 
         }
        else if( error.status === 404 )
        {
          
          this.userDoesNotExist = true;
        }
      });
  }
  onSubmitFormVerifyOtp(){
    if (this.formVerifyOtp.invalid) 
    {
      return;
    }
    this.incorrectOtp = false;
    if( this.responseForRequestOtp !== undefined)
      this.formVerifyOtp.controls['userId'].setValue(this.responseForRequestOtp.userId);
      this.spinnerService.show();
      this.service.verifyOTP(this.formVerifyOtp.value)
      .subscribe(
      response => 
      {
        this.spinnerService.hide();
        this.responseForVerifyOtp = response.json();
        this.displayFormRequestOtp = "none"; 
        this.displayFormVerifyOtp = "none"; 
        this.displayFormCreatePassword = "block";
      },error=>{
        this.spinnerService.hide();
        this.incorrectOtp = true;
      });
  }
  validateAllFormFields(formGroup: FormGroup) {    
    Object.keys(formGroup.controls).forEach(
      field => 
      {  
        const control = formGroup.get(field);             
        if (control instanceof FormControl) 
        {             
          control.markAsTouched({onlySelf: true});
        } 
        else 
        if (control instanceof FormGroup) 
        {        
          this.validateAllFormFields(control);            
        }
      });
  }
  onSubmitFormCreatePassword(){
    this.formCreatePassword.controls['userId'].setValue(this.responseForRequestOtp.userId);
    if (this.formCreatePassword.invalid) 
    {
      return;
    }
    this.spinnerService.show();
    this.service.createPassword(this.formCreatePassword.value)
    .subscribe(response =>
    {
      this.spinnerService.hide();
      this.responseForCreateNewPasswordOtp = response.json();
      this.displayFormRequestOtp = "none";
      this.displayFormVerifyOtp = "none";
      this.displayFormCreatePassword = "none";
      this.router.navigate(['/login',this.responseForRequestOtp.userName]);
    },(error)=>{
      this.spinnerService.hide();
    });
  }
  onButtonResendOtp(){
    this.otp.enable({onlySelf:true});
    this.incorrectOtp = false;
    this.displayButtonResendOtp = false; 
    this.displayButtonFormVerifyOtpSubmit  = true;
    this.formVerifyOtp.get('otp').setValue("");
    this.formVerifyOtp.get('otp').markAsUntouched({onlySelf: true});
    setTimeout(()=>
    { 
      this.displayButtonResendOtp = true; 
      this.displayButtonFormVerifyOtpSubmit  = false;
      this.otp.markAsPristine({onlySelf:true});
      this.otp.disable({onlySelf:true});
      this.incorrectOtp = false;
    }, 1000*60);
    this.spinnerService.show();
    this.service.getOTP(this.formRequestOtp.value).subscribe( response => {
      this.spinnerService.hide();
      this.responseForRequestOtp =  response.json();
      this.displayFormRequestOtp = "none"; 
      this.displayFormVerifyOtp = "block"; 
      this.displayFormCreatePassword = "none";
    },(error)=>{
      this.spinnerService.hide();
    });
  }
  emailCheckboxClicked(control : HTMLInputElement){
    this.emailOptionChecked =  control.checked;
    if( !this.smsOptionChecked )
      this.formerror = !control.checked;
  }
  smsCheckboxClicked(control : HTMLInputElement){
    this.smsOptionChecked =  control.checked;
    if( !this.emailOptionChecked )
      this.formerror = !control.checked;
  }
  get email(){
    return this.formRequestOtp.get('email');
  }
  get otp(){
    return this.formVerifyOtp.get('otp');
  }
  get password(){
    return this.formCreatePassword.get('password');
  }
  get confirmPassword(){
    return this.formCreatePassword.get('confirmPassword');
  }
  /** remove error message after 5 seconds */
  removeErrorMessage() {
    setTimeout(function() {
      this.errormessage = null;
      this.userDoesNotExist = false;
    }.bind(this), environment.errorTimeoutms);

  }
}
// description of fields -
// optOption : 1. mail 2. message 3. both
// requestFor : 1. forgotPassword 2.  forgotMail
