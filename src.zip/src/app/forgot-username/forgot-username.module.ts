import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ForgotUsernameRoutingModule } from './forgot-username-routing.module';
import { ForgotUsernameComponent } from './forgot-username/forgot-username.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    ForgotUsernameRoutingModule, ReactiveFormsModule,FormsModule
  ],
  declarations: [ForgotUsernameComponent]
})
export class ForgotUsernameModule { }
