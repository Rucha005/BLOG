import { ForgotUsernameService } from './forgot-username.service';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { timeout } from 'q';
import { GetOtpResponse } from './get-otp-response';
import { VerifyOTP } from './verify-otp';
import { JwtHelperService} from '@auth0/angular-jwt';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'forgot-username',
  templateUrl: './forgot-username.component.html',
  styleUrls: ['./forgot-username.component.css']
})

export class ForgotUsernameComponent implements OnInit
{
  responseForRequestOtp : GetOtpResponse;
  responseForVerifyOtp : VerifyOTP;
  responseForCreateNewPasswordOtp;
  displayFormRequestOtp = "none";
  displayFormVerifyOtp = "none";
  displayFormCreatePassword = "none";
  displayButtonFormVerifyOtpSubmit  = true;
  emailOptionChecked: boolean;
  smsOptionChecked : boolean;
  displayButtonResendOtp  = false;
  formerror = true;  
  incorrectOtp = false;
  userDoesNotExist = false;
  errormessage = null;

  constructor(private fb:FormBuilder, private service : ForgotUsernameService, private route:ActivatedRoute, private router : Router,private spinnerService: Ng4LoadingSpinnerService) { 
      if(this.isLoggedIn())
      this.router.navigate(['/home'])
  }
  isLoggedIn() 
  {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (currentUser) 
    {
      let token = currentUser && currentUser.token;
      if (token) 
      {
        let jwtHelper = new JwtHelperService();
        let expirationDate = jwtHelper.getTokenExpirationDate(token);
        let isExpired = jwtHelper.isTokenExpired(token);
        if (isExpired) 
        {
          return false;
        }
        else 
        {
          return true;
        }
      }
    }
    else if(currentUser == null) 
    {
      return false;
    }
  }
  ngOnInit()
  {
    this.route.paramMap.
    subscribe(params=> 
    {
      this.formRequestOtp.controls['requestFor'].setValue(params.get('requestType')); 
      if( this.formRequestOtp.controls['requestFor'].value == "forgotUsername")
      {
          this.displayFormRequestOtp = "block";
          this.displayFormVerifyOtp = "none";
          this.displayFormCreatePassword = "none";
      }
    });
  }
  formRequestOtp = new FormGroup({
    email : new FormControl(''),
    otpOption : new FormControl,
    requestFor : new FormControl,
    mobileNo : new FormControl('',Validators.required)
  });
  formVerifyOtp = new FormGroup({
    otp : new FormControl('',
      [ 
        Validators.required,
        Validators.minLength(4),
        Validators.maxLength(4),
        Validators.pattern("[0-9]+")
      ]
    ),
    userId : new FormControl
  });
  onSubmitFormRequestOtp()
  {
    if (this.formRequestOtp.invalid) 
    {
      return;
    }    
    this.formRequestOtp.controls['otpOption'].setValue('message');
    this.spinnerService.show();
    this.service.getOTP(this.formRequestOtp.value)
    .subscribe( 
      response => 
      {
        this.spinnerService.hide();
        this.responseForRequestOtp = response.json();
        this.displayFormRequestOtp = "none";
        this.displayFormVerifyOtp = "block"; 
        this.displayFormCreatePassword = "none";  
        setTimeout(()=>
        { 
          this.displayButtonResendOtp = true; 
          this.displayButtonFormVerifyOtpSubmit  = false;
          this.otp.markAsPristine({onlySelf:true});
          this.otp.disable({onlySelf:true});
          this.incorrectOtp = false;
        }, 1000*60);
      }, 
      (error:Response)=>
      {
        this.spinnerService.hide();
        if( error.status === 429 ) // otp already sent
        {
           this.errormessage = "You are already request for otp";
           this.removeErrorMessage() ;
        }
        else if( error.status === 406 )
        {
           this.errormessage = "You have reached maximum limit of OTP for the day";
        }
        else if( error.status === 404 )
        {
          this.userDoesNotExist = true;
        }
      });
  }
  onSubmitFormVerifyOtp()
  {
    if (this.formVerifyOtp.invalid) 
    {
      return;
    }
    this.incorrectOtp = false;
    if( this.responseForRequestOtp !== undefined)
      this.formVerifyOtp.controls['userId'].setValue(this.responseForRequestOtp.userId);
    this.spinnerService.show();
    this.service.verifyOTP(this.formVerifyOtp.value)
    .subscribe(
      response => 
      {
        this.spinnerService.hide();
        this.responseForVerifyOtp = response.json();
        this.displayFormRequestOtp = "none"; 
        this.displayFormVerifyOtp = "none"; 
        this.router.navigate(['/login',this.responseForRequestOtp.userName]);
      },
      error=>
      {
        this.spinnerService.hide();
        this.incorrectOtp = true;
      });
  }
  validateAllFormFields(formGroup: FormGroup) 
  {    
    Object.keys(formGroup.controls).forEach(
      field => 
      {  
        const control = formGroup.get(field);             
        if (control instanceof FormControl) 
        {             
          control.markAsTouched({onlySelf: true});
        } 
        else 
        if (control instanceof FormGroup) 
        {        
          this.validateAllFormFields(control);            
        }
      });
  }  
  onButtonResendOtp()
  {
    this.otp.enable({onlySelf:true});
    this.incorrectOtp = false;
    this.displayButtonResendOtp = false; 
    this.displayButtonFormVerifyOtpSubmit  = true;
    this.formVerifyOtp.get('otp').setValue("");
    this.formVerifyOtp.get('otp').markAsUntouched({onlySelf: true});
    setTimeout(()=>
    { 
      this.displayButtonResendOtp = true; 
      this.displayButtonFormVerifyOtpSubmit  = false;
      this.otp.markAsPristine({onlySelf:true});
      this.otp.disable({onlySelf:true});
      this.incorrectOtp = false;
    }, 1000*60);
      this.spinnerService.show();
      this.service.getOTP(this.formRequestOtp.value).subscribe( response => {
        this.spinnerService.hide();
        this.responseForRequestOtp =  response.json();
        this.displayFormRequestOtp = "none"; 
        this.displayFormVerifyOtp = "block"; 
        this.displayFormCreatePassword = "none";
      },(error)=>{
        this.spinnerService.hide();
      });
  }
  get email()
  {
    return this.formRequestOtp.get('email');
  }
  get mobileNo()
  {
    return this.formRequestOtp.get('mobileNo');
  }
  get otp()
  {
    return this.formVerifyOtp.get('otp');
  }
  /** remove error message after 5 seconds */
  removeErrorMessage() 
  {
    setTimeout(function() 
    {
      this.errormessage = null;
      this.userDoesNotExist = false;
    }.bind(this), 5000);

  }
}
// description of fields -
// optOption : 1. mail 2. message 3. both
// requestFor : 1. forgotPassword 2.  forgotMail
