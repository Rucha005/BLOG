import { TestBed, inject } from '@angular/core/testing';

import { ForgotUsernameService } from './forgot-username.service';

describe('ForgotPasswordService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ForgotUsernameService]
    });
  });

  it('should be created', inject([ForgotUsernameService], (service: ForgotUsernameService) => {
    expect(service).toBeTruthy();
  }));
});
