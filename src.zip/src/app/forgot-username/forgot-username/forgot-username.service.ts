
import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import { AllServices } from '../../common/allservices.services';

@Injectable()
export class ForgotUsernameService 
{
  
  private urlToGetOtp;
  private urlToVerifyOtp;
  private urlToCreatePassword;

  constructor(private http: Http, private allServices : AllServices) 
  {
    this.urlToGetOtp = AllServices.ip + "/getOtp";
    this.urlToVerifyOtp =  AllServices.ip + "/verifyOtp";
    this.urlToCreatePassword =  AllServices.ip + "/createPassword";
  }
  
  getOTP(getOtpObject)
  {
    return this.http.post(this.urlToGetOtp, getOtpObject);
  }

  verifyOTP(verifyOtpObject)
  {
    return this.http.post(this.urlToVerifyOtp, verifyOtpObject);
  }

  createPassword(newPasswordObject)
  {
    return this.http.post(this.urlToCreatePassword, newPasswordObject);
  }
}
