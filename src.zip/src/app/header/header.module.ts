import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderRoutingModule } from './header-routing.module';
import { HeaderComponent } from './header/header.component';
import { MatExpansionModule } from '@angular/material/expansion';
import { ProductService } from '../common/product.service';
import { ProductCartService } from '../common/product-cart.service';
import { RegistartionService } from '../common/registartion.service';
import { LevelDataService } from '../common/levelData.service';
import {FormsModule,ReactiveFormsModule}  from '@angular/forms'
import { AllServices } from '../common/allservices.services';

@NgModule({
  imports: [
    CommonModule,
    HeaderRoutingModule,FormsModule,ReactiveFormsModule,
    MatExpansionModule
  ],
  declarations: [HeaderComponent],
  exports:[HeaderComponent],
  providers:[ProductService, ProductCartService, RegistartionService, LevelDataService,AllServices]
})
export class HeaderModule { }
