import { LOCAL_STORAGE, WINDOW } from '@ng-toolkit/universal';
import { Component, OnInit, Input, ViewChild, ElementRef, AfterViewInit, Output, EventEmitter, HostListener, Inject } from '@angular/core';
import { FormBuilder, FormArray } from '@angular/forms';
import { RouterModule, ActivatedRoute, Router } from '@angular/router';
import { LevelOneData } from './allLevel';
import { Products } from '../../products/products/products';
import { ErrorStatus } from '../../common/ErrorStatus';
import { ProductCartService } from '../../common/product-cart.service';
import { ProductService } from '../../common/product.service';
import { LoginService } from '../../login/login/login.service';
import { RegistartionService } from '../../common/registartion.service';
import { LevelDataService } from '../../common/levelData.service';
import { Subscription } from 'rxjs/Subscription';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})

export class HeaderComponent implements OnInit {

  @ViewChild('navid') navid: ElementRef;
  wishlistdata: any;
  cartddatacount: string;
  showsearchform: boolean = false;
  showSelected: boolean;
  ShowMenuSelected: boolean;
  levelOneData: LevelOneData[];
  items: Products[] = [];
  username: any;
  userData: any;
  currentUser: any;
  customerId: number;
  static cartCount = 0;
  static wishlistCount = 0;
  static cartData = null;
  errorStatus: ErrorStatus;

  constructor(@Inject(WINDOW) private window: Window, @Inject(LOCAL_STORAGE) private localStorage: any,
    private productService: ProductService, private loginService: LoginService, private cartService: ProductCartService,
    private registrationservice: RegistartionService, private route: ActivatedRoute,private spinnerService: Ng4LoadingSpinnerService,
    private router: Router, private leveldataservice: LevelDataService) 
  {
    this.showSelected = false;
    if (this.localStorage.getItem('currentUser'))
      this.currentUser = JSON.parse(this.localStorage.getItem('currentUser'));
  }

  get LoginService() 
  {
    return this.loginService;
  }

  /** check logged in or not */
  ngOnInit() 
  {
    this.getAllMenuLevels();
    if (this.loginService.isLoggedIn()) 
    {
      this.username = this.currentUser.username;
      //console.log("username oninit: " + this.username);
      this.getByUsername();
    }
    else 
    {
      this.cartItemCountFromLocalStorage();
    }
  }

  /** get all data by customer */
  getByUsername() 
  {
     this.username = this.currentUser.username;
     this.registrationservice.getByUsername(this.username).subscribe(items => 
     {
       this.userData = items;
       this.customerId = items.userId;
       this.loadAllCartDataByCustomerId();
     }, 
     (error) => 
     {
     });
  }

  /** show support div */
  showSupportButton() 
  {
    this.showSelected = true;
  }

  /** hide support div */
  hideSupportButton() 
  {
    this.showSelected = false;
  }

  /** get all menus / levels data */
  getAllMenuLevels() 
  {
    this.leveldataservice.getLevelOneAll()
    .subscribe(items => 
    {
      this.levelOneData = items;
      for (let i = 0; i < this.levelOneData.length; ++i) 
      {
        this.leveldataservice.getLevelTwoAllById(this.levelOneData[i].levelOneId)
        .subscribe(levelTwoItems => 
        {
          this.levelOneData[i].levelTwo = levelTwoItems;
          for (let j = 0; j < this.levelOneData[i].levelTwo.length; ++j) 
          {
            this.leveldataservice.getLevelThreeAllById(this.levelOneData[i].levelTwo[j].levelTwoId)
            .subscribe(levelThreeItems => 
            {
              this.levelOneData[i].levelTwo[j].levelThree = levelThreeItems;
              for (let k = 0; this.levelOneData[i].levelTwo[j].levelThree!=null &&k < this.levelOneData[i].levelTwo[j].levelThree.length; ++k) 
              {
                this.leveldataservice.getLevelFourAllById(this.levelOneData[i].levelTwo[j].levelThree[k].levelThreeId)
                .subscribe(levelFourItems => 
                {
                  this.levelOneData[i].levelTwo[j].levelThree[k].levelFour = levelFourItems;
                })
              }
            });
          }
        });
      }
    },
    (error) => 
    {
    });
  }
  
  /**show search input */
  showSearch() 
  {
    this.showsearchform = !this.showsearchform;
  }
 
  /** get cart count */
  get getCartCount() 
  {
    if (this.loginService.isLoggedIn()) 
    {
      return HeaderComponent.cartCount;
    }
    else 
    {
      return this.cartService.countCartItems();
    }
  }

  /** get wishlist count */
  get getWishlistCount() 
  {
    if (this.loginService.isLoggedIn()) 
    {
      return HeaderComponent.wishlistCount;
    }
    else 
    {
      return this.cartService.countWithListItems();
    }
  }

  /** get cart data */
  get getCartItems() 
  {
    return HeaderComponent.cartData;
  }

  /** get cart data count from localstorage */
  cartItemCountFromLocalStorage() 
  {
    HeaderComponent.cartCount = 0;
    this.items = null;
    if (this.localStorage.getItem('cartData')) 
    {
      this.items = JSON.parse(this.localStorage.getItem('cartData'));
      if (this.items != null) 
      {
        HeaderComponent.cartCount = this.items.length;
        HeaderComponent.cartData = this.items;
      }
    }
    return this.items;
  }
  
  /** load / display all data by customer */
  loadAllCartDataByCustomerId() 
  {
    this.cartService.loadAllCartDataByCustomerId(this.customerId).subscribe(s => 
    {
      this.items = s;
      HeaderComponent.cartData = this.items;
      this.cartItemCountFromDb();
      this.WishlistItemCountFromDb();
    },
    (error) => 
    {
        this.errorStatus = JSON.parse(error._body);
        if (this.errorStatus.status = 404) 
        {
          HeaderComponent.cartCount = 0;
        }
    });
  }

  /** get cart data count from db when login */
  cartItemCountFromDb() 
  {
    this.spinnerService.show();
    this.cartService.cartItemCount(this.customerId, 'CART').subscribe(s => 
    {
      this.spinnerService.hide();
      HeaderComponent.cartCount = s.count;
    },
    (error) => 
    {
      this.spinnerService.hide();
    });
  }

  /** get wishlist data count from db */
  WishlistItemCountFromDb() 
  {
    this.spinnerService.show();
    this.cartService.loadAllWishlistDataByCustomerId(this.customerId).subscribe(s => 
    {
      this.spinnerService.hide();
      this.wishlistdata = s;
      HeaderComponent.wishlistCount = this.wishlistdata.length;
    },
    (erorr) => 
    {
        this.spinnerService.hide();
    });
  }

  /** check levels name (NA) */
  showLevel(levelname: string) 
  {
    if (levelname == 'NOT APPLICABLE' || levelname == 'not applicable' || levelname == 'Not Applicable' || levelname == 'NA' || levelname == 'na' || levelname == 'Na') 
    {
      return true;
    }
    else 
    {
      return false;
    }
  }

  /** on scroll display header(menu) */
  @HostListener("window:scroll", ['$event'])
  onScroll(event) 
  {
    if (this.window.pageYOffset > 50) 
    {
      this.navid.nativeElement.classList.add("navbar1");
    }
    else 
    {
      this.navid.nativeElement.classList.remove("navbar1");
    }
  }

  /** show menu (mobile view) */
  ShowMenuButton() 
  {
    this.ShowMenuSelected = true;
  }
  
  /** hide menu div (mobile view) */
  HideMenuButton() 
  {
    this.ShowMenuSelected = false;
  }

  /** navigate to product details page */
  navigate(event, levelFourId) 
  {
    this.router.navigate(['/productlist/levelFour/', levelFourId]);
    this.HideMenuButton();
  }
}
