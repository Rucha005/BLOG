import { Subscription } from 'rxjs/Subscription';    
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'home-slider',
  templateUrl: './home-slider.component.html',
  styleUrls: ['./home-slider.component.css']
})

export class HomeSliderComponent
{
  url : string;
  loadAPI: Promise<any>;
  ngOnInit() 
  {
    this.loadAPI = new Promise((resolve) => 
    {
      
      this.url = "assets/js/trigger/slider/ios/kl-ios-slider.js",
      this.loadScript();

    });    
  }

  public loadScript() 
  {
    let node = document.createElement('script');
    node.src = this.url;
    node.type = 'text/javascript';
    node.async = true;
    node.charset = 'utf-8';
    document.getElementsByTagName('head')[0].appendChild(node);
  }
}

