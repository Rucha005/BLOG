import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home/home.component';
import { HomeSliderModule } from '../home-slider/home-slider.module';
import { SwiperModule } from 'angular2-useful-swiper';
import { NgxSlideshowModule } from 'ngx-slideshow';
import { WishlistModule } from '../wishlist/wishlist.module';
import { AllServices } from '../common/allservices.services';
@NgModule({
  imports: [
    CommonModule,
    HomeRoutingModule,
    HomeSliderModule,
    SwiperModule,
    NgxSlideshowModule,
    WishlistModule
  ],
  declarations: [HomeComponent],
  providers:[AllServices],
  exports:[HomeComponent]
})
export class HomeModule { }
