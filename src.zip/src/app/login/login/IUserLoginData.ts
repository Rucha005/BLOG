export interface IUserLoginData {
	username:string;
    sub: string;
    aud:  string; 
    exp:  string;
    iat:  string;
    role: string;
}


export interface Irole{
    authority:string;
}