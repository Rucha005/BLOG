import { MyProductReviewModule } from './my-product-review.module';

describe('MyProductReviewModule', () => {
  let myProductReviewModule: MyProductReviewModule;

  beforeEach(() => {
    myProductReviewModule = new MyProductReviewModule();
  });

  it('should create an instance', () => {
    expect(myProductReviewModule).toBeTruthy();
  });
});
