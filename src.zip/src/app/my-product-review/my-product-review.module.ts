import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MyProductReviewRoutingModule } from './my-product-review-routing.module';
import { MyProductReviewComponent } from './my-product-review/my-product-review.component';
import { RatingService } from '../common/rating.service';

@NgModule({
  imports: [
    CommonModule,
    MyProductReviewRoutingModule
  ],
  declarations: [MyProductReviewComponent],
  providers:[RatingService],                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
  exports:[MyProductReviewComponent]
})
export class MyProductReviewModule { }
