import { LOCAL_STORAGE , WINDOW} from '@ng-toolkit/universal';
import { Component, OnInit, ElementRef, ViewChild, Input, Output, HostListener, Inject, Renderer2 } from '@angular/core';
import { FormGroup, FormBuilder,Validators,FormControl, FormsModule} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ErrorStatus } from '../../common/ErrorStatus';
import { RegistartionService } from '../../common/registartion.service';
import { RatingService } from '../../common/rating.service';
import { AddressService } from '../../common/address.service';
import { MyOrderService } from '../../common/myorder.service';
import { environment } from '../../../environments/environment';
import { MyProductReviewComponent } from '../../my-product-review/my-product-review/my-product-review.component';
import { HeaderComponent } from '../../header/header/header.component';

@Component({
  selector: 'app-myaccount',
  templateUrl: './myaccount.component.html',
  styleUrls: ['./myaccount.component.css']
})
export class MyAccountComponent implements OnInit {
  contactInfoSubmit: boolean;
  today: string;
  editInfoModal: any;
  contactSuccessMessage: string;
  editUserForm: FormGroup;
  deleteAddressSuccessMessage: any;
  showcancelordertab: any;
  items: any;
  AddressErrorMessage: string;
  addressSubmit: boolean;
  orderErrorMessage: string;
  errorStatus: ErrorStatus;
  customerSuccessMessage: string;
  index: any;
  customerId:number;
  orderItems:any;
  viewOrderList:any;
  viewOrderFlag:boolean;
  rentOrderId:number;
  viewPlaceOrder:any;
  userData: any;
  username : any;
  address: any;
  addtesstype:any;
  addressForm: FormGroup;
  customerErrorMessage= null;
  shownewAddress:boolean =true;
  orderItemsIndex:number;
  productid:number;
  showreview:boolean = false;
  onOrderCancelSubmit : boolean = false;
  
  constructor(@Inject(WINDOW) private window: Window, @Inject(LOCAL_STORAGE) private localStorage: any, private spinnerService: Ng4LoadingSpinnerService,
  private datePipe: DatePipe,private router:Router,private route:ActivatedRoute,private fb: FormBuilder,private registrationservice:RegistartionService,
  private orderService: MyOrderService,private ratingservice: RatingService,private addressservice: AddressService) 
  { 
    this.addressForm = this.fb.group({
      'addressId':[null, Validators.required],
	    'addressType':['', Validators.required],
	    'city':['', Validators.required],
	    'houseNo':['', Validators.required],
	    'landmark':['', Validators.required],
	    'localityArea':['', Validators.required],
	    'nameOfHouse':['', Validators.required],
	    'pinNo':['', Validators.required],
	    'road':['', Validators.required],
	    'state':['Maharashtra', Validators.required],
	    'alternatePhone':['', Validators.required],
	    'coNote':['', Validators.required]
    })
    this.editUserForm = this.fb.group({
      'firstName':['', Validators.required],
      'phone':['', Validators.required],
      'lastName':['', Validators.required],
      'userId':['', Validators.required],
     })
     let date = new Date;
     this.today = this.datePipe.transform(date, 'dd-MMM-yyyy');
  }
  ngOnInit() 
  {
    this.getByUsername();
    this.viewOrderList = true;
  }
  /** get data by user name */
  getByUsername() 
  {
    if( this.localStorage.getItem('currentUser') )
    {
      const currentUser = JSON.parse(this.localStorage.getItem('currentUser'));
      this.spinnerService.show();
      this.registrationservice.getByUsername(currentUser.username)
      .subscribe(items => 
      {
        this.username= currentUser.username; 
        this.userData = items; 
        this.customerId = items.userId
        this.spinnerService.hide();
        this.loadUserAddress();
        this.onEmitOfEventNavigateAfterPlaceOrder(true);
        this.getstyle();
      },
      (error)=>
      {
        this.spinnerService.hide();
      });
    }
  }
  /** edit contact information - (user data) */
  editContactInfo(userdata)
  {
    this.editUserForm.controls["firstName"].setValue (userdata.firstName);
    this.editUserForm.controls["phone"].setValue (userdata.phone);
    this.editUserForm.controls["lastName"].setValue (userdata.lastName);
    this.editUserForm.controls["userId"].setValue (userdata.userId);
  }
  submitContactInfo()
  {
      this.orderService.editContactInfo(this.editUserForm.value).subscribe(response => {
      this.contactSuccessMessage = "Information Updated Successfully.";
      this.getByUsername();
      this.editInfoModal = true;
    });
  }
  /** edit modal cancel click */
  cancelModal()
  {
    this.editInfoModal = false;
    this.contactInfoSubmit = true;
  }
  /** load / display place order summery by customer*/
  loadPlaceOrderItemsByCustomerId()
  {
    this.orderItems = [];
    this.spinnerService.show();
    this.orderService.loadPlaceOrderItemsByCustomerId(this.customerId)
    .subscribe(items => 
    {
      this.spinnerService.hide();
      this.orderItems = items;
    },
    (error)=>
    {
      this.spinnerService.hide();
      this.errorStatus = JSON.parse(error._body);
      if (this.errorStatus.status = 404) 
      {
        this.orderErrorMessage =  this.errorStatus.errorMessage
      }
   });

  }
  /** display order details by order id */
  viewOrder(product)
  {
    this.rentOrderId = product.rentOrderId;
    this.viewOrderList = false;
    this.viewOrderFlag = true;
    this.spinnerService.show();
    this.orderService.viewOrderByOrderId(product.rentOrderId).subscribe(items => {
      this.spinnerService.hide();
      this.viewPlaceOrder = items
    },(error)=>{
      this.spinnerService.hide();
    });  
  }
  getTotalDeposit(orderitems)
  {
    let deposit =0;
    for(let  c of orderitems.rentOrderItems)
    {
      deposit = (deposit + c.deposit) * c.orderedProductQuantity;
    }
    return deposit;
  }
  /** print invoice */
  print(): void 
  {
    let printContents, popupWin, printContents1;
    printContents = document.getElementById('print-section').innerHTML;
    printContents1 = document.getElementById('print-section1').innerHTML;
    popupWin = this.window.open('', '_blank', 'top=0,left=0,height=100%,width=auto');
    popupWin.document.write(`<html> <head> <title>Invoice</title> <style>//........Customized style....... table{font-family: arial, sans-serif; border-collapse: collapse; width: 100%;}</style> </head> <body onload='window.print();window.close()'> <table style="width:900px;"> <thead> <tr class="first last"> <th> <img src="assets/images/logoF1.png" style="width:250px; height:120px;"> <p style="font-size:12px;">Voyagekart is division of The Pentade</p></th> <th> <p><u>A Platform to Rent Travel bags and Travel Gear</u></p><p>THE PENTADE</p><p>A-3, Ashwini Society, Pune Mumbai Road, Shivajinagar,</p><p>Pune - 411005, INDIA</p></th> </tr></thead> </table> ${printContents}</body> </html> <html> <head> <title>Invoice</title> <style>//........Customized style....... table{font-family: arial, sans-serif; border-collapse: collapse; width: 100%;}</style> </head> <body onload='window.print();window.close()'> <table style="width:900px; margin-top:20% !important; padding:2px;"> <thead> <tr class="first last"> <th> <img src="assets/images/logoF1.png" style="width:250px; height:120px; float:left;"><br></th> </tr></thead> </table> <table style="width:900px;padding:2px;"> <thead> <tr class="first last"> <th> <p style="font-size:12px;float:left;">Voyagekart is division of The Pentade</p></th> </tr><tr class="first last"> <th> <p style="float:left;">The Pentade, A-3, Ashwini Society, Pune Mumbai Road, Shivajinagar, Pune - 411005, INDIA</p></th> </tr></thead> </table> ${printContents1}</body> </html>`);
    popupWin.document.close();
  }
  /** Address */
  loadUserAddress() 
  {
    this.address = [];
    this.spinnerService.show();
    this.addressservice.loadUserAddress(this.customerId).subscribe(s => {
      this.spinnerService.hide();
      this.address = s;
    },(error)=>{ 
      this.spinnerService.hide();
      this.errorStatus = JSON.parse(error._body);
      if (this.errorStatus.status = 404) 
      {
        this.AddressErrorMessage =  this.errorStatus.errorMessage
      }
    });
  }
  resetaddress()
  { 
    this.addressForm.controls["addressId"].setValue(null);
    this.customerErrorMessage = null;
    this.customerSuccessMessage = null;
    this.shownewAddress = true;
    this.addressForm.controls["addressId"].reset();
    this.addressForm.controls["houseNo"].reset(); 
    this.addressForm.controls["landmark"].reset(); 
    this.addressForm.controls["localityArea"].reset(); 
    this.addressForm.controls["nameOfHouse"].reset(); 
    this.addressForm.controls["pinNo"].reset(); 
    this.addressForm.controls["road"].reset();
  }
  addresstype(value) 
  {
    this.addtesstype = value;
  }
  selectcity(value)
  {
    this.addressForm.controls["city"].setValue (value);  
  }
  submitAddress()
  { 
    if(this.addtesstype == null){
      this.addressForm.controls["addressType"].setValue ('Home');
    }else{
      this.addressForm.controls["addressType"].setValue(this.addtesstype);
    } 
    
    if(this.addressForm.controls["houseNo"].valid && this.addressForm.controls["localityArea"].valid && this.addressForm.controls["nameOfHouse"].valid && this.addressForm.controls["pinNo"].valid && this.addressForm.controls["road"].valid) 
    {
      this.spinnerService.show();
      this.addressservice.addAddress(this.addressForm.value,this.customerId)
      .subscribe(response =>{
        this.spinnerService.hide();
        this.customerSuccessMessage = "Updating Address...";
        this.spinnerService.show();
        setTimeout(() =>{
          this.loadUserAddress();
          this.addressSubmit = true;
          this.shownewAddress = false;
          this.spinnerService.hide();
        }, environment.errorTimeoutms);
        this.addressSubmit = false;  
      },(error)=>{
        this.spinnerService.hide();
        this.customerErrorMessage = "Error in registration!!"
        this.removeErrorMessage()
      });
    }else{
      this.customerErrorMessage = "Please fill in all required fields"
      this.removeErrorMessage();
      return;
    }  
  }
  editAddress(address)
  {
    this.customerErrorMessage = null;
    this.customerSuccessMessage = null;
    this.shownewAddress = true;

    this.addressForm.controls["addressId"].setValue (address.addressId);
    this.addressForm.controls["addressType"].setValue (address.addressType);
    this.addressForm.controls["city"].setValue (address.city);
    this.addressForm.controls["houseNo"].setValue (address.houseNo);
    this.addressForm.controls["landmark"].setValue (address.landmark);
    this.addressForm.controls["localityArea"].setValue (address.localityArea);
    this.addressForm.controls["nameOfHouse"].setValue (address.nameOfHouse);
    this.addressForm.controls["pinNo"].setValue (address.pinNo);
    this.addressForm.controls["road"].setValue (address.road);
    this.addressForm.controls["state"].setValue (address.state);
    this.addressForm.controls["alternatePhone"].setValue (address.alternatePhone);
    this.addressForm.controls["coNote"].setValue (address.coNote);
  }
  deleteAddress(addressId)
  {
    this.addressservice.deleteUserAddress(addressId).subscribe(response => {
        this.deleteAddressSuccessMessage = "Address Deleted Successfully.";
        this.loadUserAddress();
    });  
  }
  onEmitOfEventAddressSubmit(isAddressSubmit : boolean)
  {
     this.addressSubmit = true;
  }
  
  /** Cancel order */
  cancelorder(rentOrderId, orderItemsIndex)
  {
    this.showcancelordertab = true;
    this.onOrderCancelSubmit = false;
    this.rentOrderId = rentOrderId;
    this.orderItemsIndex = orderItemsIndex;
    this.orderService.setCanceldetails(rentOrderId,orderItemsIndex);
  }
  onEmitOfEventOrderCancellation(isOrderCancelled : boolean)
  {
    this.onOrderCancelSubmit = true;
    this.orderItems[this.orderItemsIndex].cancelledStatus = isOrderCancelled;
    this.showcancelordertab = false;
  }

  /** Review and Rating*/ 
  setReview(productid,customerid,rentOrderId,index)
  {
    this.productid = productid
    this.ratingservice.setReviewdetails(productid,customerid,rentOrderId);
    this.index = index;
    this.showreview= !this.showreview;
  }
  onEmitOfEventReviewSubmit(isReviewSubmit : boolean)
  {
    this.onOrderCancelSubmit = true;
    this.showreview= !this.showreview;
    this.loadPlaceOrderItemsByCustomerId();
  }
 
  /** logout */
  logout() 
  {
    this.localStorage.removeItem('currentUser');
    this.localStorage.removeItem('cartData');
    HeaderComponent.cartCount =0;
    this.items = null;
    this.router.navigate(['/home/'])
  }
  
  /** remove error message after 5 seconds */
  removeErrorMessage() 
  {
    setTimeout(function() {
      this.customerErrorMessage = null;
      this.customerSuccessMessage = null;
    }.bind(this),environment.errorTimeoutms);
  }
  onEmitOfEventNavigateAfterPlaceOrder(eventNavigateToMyOrder:boolean)
  {
    this.onOrderCancelSubmit = true;
    this.loadPlaceOrderItemsByCustomerId();
  }

  /** navigate to product details page */
  navigate(event,modelId,rentTransactionId,levelOneId,levelFourId)
  {
    this.localStorage.removeItem('leveloneid');
    this.localStorage.setItem('levelOne',levelOneId);
    this.localStorage.setItem('levelFour',levelFourId);
    this.router.navigate(['/product/', modelId ,rentTransactionId])
    event.preventDefault();
    event.stopPropagation();
  } 

  /** styles for orders which is done */
  getstyle()
  {
    //console.log("All orders: " + JSON.stringify(this.orderItems))
  }

  getDeposite()
  {

  }
}