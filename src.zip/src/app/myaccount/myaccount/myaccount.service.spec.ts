import { TestBed, inject } from '@angular/core/testing';

import { MyaccountService } from './myaccount.service';

describe('MyaccountService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MyaccountService]
    });
  });

  it('should be created', inject([MyaccountService], (service: MyaccountService) => {
    expect(service).toBeTruthy();
  }));
});
