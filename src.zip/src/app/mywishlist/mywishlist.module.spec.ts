import { MywishlistModule } from './mywishlist.module';

describe('MywishlistModule', () => {
  let mywishlistModule: MywishlistModule;

  beforeEach(() => {
    mywishlistModule = new MywishlistModule();
  });

  it('should create an instance', () => {
    expect(mywishlistModule).toBeTruthy();
  });
});
