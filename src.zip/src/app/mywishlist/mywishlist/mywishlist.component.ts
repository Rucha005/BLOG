import { LOCAL_STORAGE } from '@ng-toolkit/universal';
import { Component, OnInit , Inject} from '@angular/core';
import { DatePipe } from '@angular/common';
import { Route, Router } from '@angular/router';
import { Products } from '../../products/products/products';
import { ErrorStatus } from '../../common/ErrorStatus';
import { LoginService } from '../../login/login/login.service';
import { RegistartionService } from '../../common/registartion.service';
import { ProductCartService } from '../../common/product-cart.service';
import { HeaderComponent } from '../../header/header/header.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'app-mywishlist',
  templateUrl: './mywishlist.component.html',
  styleUrls: ['./mywishlist.component.css']
})
export class MywishlistComponent implements OnInit {

  currentUser: any;
  customerId: any;
  userData: any;
  username: any;
  isInWishlist: boolean;
  items:Products[]=[];
  specialPrice:number;
  rentPerDay: number;
  percentage: number;
  errorStatus: ErrorStatus;

  constructor(@Inject(LOCAL_STORAGE) private localStorage: any, private datePipe: DatePipe, private loginService:LoginService, private route :Router,
    private cartService: ProductCartService,private registrationservice:RegistartionService,private spinnerService: Ng4LoadingSpinnerService) 
  { 
      this.items = JSON.parse(localStorage.getItem('cartData'))
      this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
      if (loginService.isLoggedIn()) 
      {
      this.getByUsername();
      }
  }
  ngOnInit() 
  {
  }
  getByUsername() 
  {
      this.username = this.currentUser.username;
      this.registrationservice.getByUsername(this.username).subscribe(items => {
        this.userData = items;
        this.customerId = items.userId;
        this.loadAllWishlistDataByCustomerId();
      },(error)=>{});
  }
  get getCartCount() 
  {
    if(this.loginService.isLoggedIn()) 
    {
    return HeaderComponent.cartCount;
    }
    else
    {
      return this.cartService.countCartItems();
    } 
  }
  get getWishlistCount()
  {
    if(this.loginService.isLoggedIn()) 
    {
      return HeaderComponent.wishlistCount;
    }
    else
    {
      return this.cartService.countWithListItems();
    }  
  }
  removeItemFromWishlist(product:Products)
  {
      if(this.loginService.isLoggedIn())
      {
        // remove from cart item 
        for(let p =0; p<this.items.length; p++)
        { 
          if(this.items[p].rentTransactionId === product.rentTransactionId ){
            this.spinnerService.show();   
            this.cartService.removeCartFromDatabase(product.rentCartId).subscribe(() => {
            this.spinnerService.hide();   
            product.isInWishlistFlag = false;
            this.loadAllWishlistDataByCustomerId();
            },
            (error) => {
              this.spinnerService.hide();  
              this.errorStatus = JSON.parse(error._body);
              if (this.errorStatus.status = 404) {
                HeaderComponent.wishlistCount = 0;
              } 
            })
          }
        }    
      }
      else
      {
        for(let p =0; p<this.items.length; p++)
        {
          if(this.items[p].rentTransactionId === product.rentTransactionId )
          {
            if(this.items[p].cartType == "WISHLIST")
            {
              this.items[p].cartType = "WISHLIST";
              this.items.splice(p,1);
              this.localStorage.setItem('cartData',  JSON.stringify(this.items));
              break;
            }
          }
        } 
      } 
  }
  addItemToCart(product:Products)
  {
      if(this.loginService.isLoggedIn())
      {
    //Add item to cart Service CALL     
        if(product.cartType = "WISHLIST")
        {
          this.removeItemFromWishlist(product);
          this.route.navigate(['product/'+product.modelId,product.rentTransactionId]);
          this.localStorage.setItem('moveFromWishlistFlag','true');
        }
        else
        {
          product.cartType = "WISHLIST";
          //Add item to cart Service CALL
          this.spinnerService.show();   
          this.cartService.moveDataToWishlistOrCart(product.rentCartId,product.cartType).subscribe(s => {
            this.spinnerService.hide(); 
            this.loadAllWishlistDataByCustomerId();
            product.isInWishlistFlag = false;
          },
          (error) => {
            this.spinnerService.hide();  
            this.errorStatus = JSON.parse(error._body);
            if (this.errorStatus.status = 404) {
              HeaderComponent.cartCount = 0;
            } 
          }) 
        }
      }
      else
      {
        for(let p =0; p<this.items.length; p++)
        {
          if(this.items[p].rentTransactionId === product.rentTransactionId )
          {
            if(this.items[p].cartType == "WISHLIST")
            {
              // if(product.bookingFromDate == null)
              // {
                this.items.splice(p,1);
                this.localStorage.setItem('cartData',  JSON.stringify(this.items));
                this.route.navigate(['product/'+product.modelId,product.rentTransactionId])
                this.localStorage.setItem('moveFromWishlistFlag','true');
                break;
              // }
              // this.items[p].cartType = "CART";
              // localStorage.setItem('cartData',  JSON.stringify(this.items));
              // break;
            }
          }
        } 
      }   
  }
  loadAllWishlistDataByCustomerId() 
  {
    this.spinnerService.show();   
    this.cartService.loadAllWishlistDataByCustomerId(this.customerId).subscribe(s => {
      this.spinnerService.hide();   
      this.items=s;
      HeaderComponent.wishlistCount = this.items.length;
    },(error) => {
      this.spinnerService.hide();
      this.errorStatus = JSON.parse(error._body);
      if (this.errorStatus.status = 404) {
        HeaderComponent.wishlistCount = 0;
      }    
    });
  }
  getRent(cart:Products)
  {
    if(cart.rentCartItemOffers.length > 0){
      for(let  c of cart.rentCartItemOffers){
        if(c.groupNo == 0){
          this.rentPerDay = cart.rentPerDay
          break;
        }else {
          this.specialPrice = cart.rentPerDay  * cart.productQuantity
        }
      }
      return this.rentPerDay;
    }
  }
}