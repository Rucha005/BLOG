import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OrderCancellationRoutingModule } from './order-cancellation-routing.module';
import { OrderCancellationComponent } from './order-cancellation/order-cancellation.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MyOrderService } from '../common/myorder.service';

@NgModule({
  imports: [
    CommonModule,
    OrderCancellationRoutingModule, FormsModule, ReactiveFormsModule
  ],
  declarations: [OrderCancellationComponent],
  providers:[MyOrderService],
  exports:[OrderCancellationComponent]
})
export class OrderCancellationModule { }
