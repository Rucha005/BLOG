import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { Route, Router } from '@angular/router';
import { ProductService } from '../../common/product.service';
import { MyOrderService } from '../../common/myorder.service';
import { ErrorStatus } from '../../common/ErrorStatus';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'app-order-cancellation',
  templateUrl: './order-cancellation.component.html',
  styleUrls: ['./order-cancellation.component.css']
})
export class OrderCancellationComponent implements OnInit {

  reason: any;
  cancellationReason:string;
  option4: any;
  myForm: FormGroup;
  cancelreason: any;
  option1: any;
  option2: any;
  option3: any;
  cancellationErrorMessage: string;
  cancelOrderErrorModal: boolean;
  cancelOrderModal: boolean;
  showtext:boolean = false;
  errorStatus: ErrorStatus;
  rentOrderId:number;
  orderItemsIndex:number;
  orderCancelForm: FormGroup;
  cancellationMessage = null;
  @Output() eventOrderCancellation = new EventEmitter<boolean>();
  
  constructor(private router: Router,private productService :ProductService,private fb: FormBuilder,private spinnerService: Ng4LoadingSpinnerService,
              private service : MyOrderService) 
  {
    this.orderCancelForm = this.fb.group(
    {
      'orderCancellationId':['', Validators.required],
      'orderCancellationReason':['', Validators.required],
    })
    this.myForm = this.fb.group({
      cancelreasons: this.fb.array([])
    });
    this.cancelOrderModal = false;
  }
  ngOnInit() 
  {}
  cancelModal()
  {
    this.cancelOrderModal= false;
    this.cancelOrderErrorModal = false;
  }
  onChange(reason: string, isChecked: boolean) {
    const reasonFormArray = <FormArray>this.myForm.controls.cancelreasons;
    if (isChecked) {
      if(reason == 'other'){
        //reasonFormArray.push(new FormControl(this.orderCancelForm.get('orderCancellationReason',)));
      }else{
        reasonFormArray.push(new FormControl(reason));
      }
    } else {
      let index = reasonFormArray.controls.findIndex(x => x.value == reason)
      reasonFormArray.removeAt(index);
    }
  }
  selectedCancelOption1(value)
  {
      this.showtext =false;
      this.option1 =value;
  }
  selectedCancelOption2(value)
  {
      this.showtext =false;
      this.option2 =value;
  }
  selectedCancelOption3(value)
  {
      this.showtext =false;
      this.option3 =value;
  }
  selectedCancelOption4(value)
  {
      this.showtext =true;
      this.option4 =value;
  }
  someFunction(){
    let rea = this.cancellationReason;
    let replacereason = rea.replace(",", "//44//");
    this.reason = replacereason
  }
  submitCancelReason()
  { 
    if(this.option1 != null && this.option2 != null && this.option3 != null && this.reason !=null){
      this.cancelreason = this.option1+","+this.option2+","+this.option3+","+this.reason;
      this.orderCancelForm.controls["orderCancellationReason"].setValue(this.cancelreason);
    }
    else if(this.option1 != null && this.option2 != null){
      this.cancelreason = this.option1+","+this.option2;
      this.orderCancelForm.controls["orderCancellationReason"].setValue(this.cancelreason);
    }
    else if(this.option1 != null && this.option3 != null){
      this.cancelreason = this.option1+","+this.option3;
      this.orderCancelForm.controls["orderCancellationReason"].setValue(this.cancelreason);
    }
    else if(this.option1 != null && this.reason != null){
      this.cancelreason = this.option1+","+this.reason;
      this.orderCancelForm.controls["orderCancellationReason"].setValue(this.cancelreason);
    }
    else if(this.option2 != null && this.option3 != null){
        this.cancelreason = this.option2+","+this.option3;
        this.orderCancelForm.controls["orderCancellationReason"].setValue(this.cancelreason);
    }
    else if(this.option2 != null && this.reason != null){
      this.cancelreason = this.option2+","+this.reason;
      this.orderCancelForm.controls["orderCancellationReason"].setValue(this.cancelreason);
    }
    else if(this.option3 != null && this.reason != null){
      this.cancelreason = this.option3+","+this.reason;
      this.orderCancelForm.controls["orderCancellationReason"].setValue(this.cancelreason);
    }
    else if(this.option1 != null){
      this.orderCancelForm.controls["orderCancellationReason"].setValue(this.option1);
    }
    else if(this.option2 != null){
      this.orderCancelForm.controls["orderCancellationReason"].setValue(this.option2);
    }
    else if(this.option3 != null){
      this.orderCancelForm.controls["orderCancellationReason"].setValue(this.option3);
    }else if(this.option4 != null){
      this.cancelreason=null;
      this.option1=null;
      this.option2=null;
      this.option3=null;
      this.orderCancelForm.controls["orderCancellationReason"].setValue(this.reason);
    }
    
     this.rentOrderId= this.service.getCancelrentOrderId();
     this.orderItemsIndex = this.service.getCancelorderItemsIndex();
     this.orderCancelForm.controls["orderCancellationId"].setValue (this.rentOrderId);
     //console.log(this.orderCancelForm.controls['orderCancellationId'].valid)
     //console.log(this.orderCancelForm.controls['orderCancellationReason'].valid)
    if(this.orderCancelForm.controls['orderCancellationId'].valid && this.orderCancelForm.controls['orderCancellationReason'].valid){
      this.spinnerService.show();   
      this.service.cancelOrder(JSON.stringify(this.orderCancelForm.value))
      .subscribe(response => 
      {
        this.spinnerService.hide();   
        this.cancellationMessage = response.successMessage; 
        this.orderCancelForm.reset();
        this.cancelOrderModal = true;   
        setTimeout(() => {
          this.eventOrderCancellation.emit(true);
        },3000);
        
      },(error)=>
      {
        this.spinnerService.hide();   
        this.errorStatus = JSON.parse(error._body);
        if (this.errorStatus.status = 417) 
        {
          this.cancellationErrorMessage = "Sorry unable to cancel your order"
          this.cancelOrderErrorModal = true;
        }
        this.orderCancelForm.reset();
        setTimeout(() => {
          this.eventOrderCancellation.emit(false);
        }, 3000);
      }); 
    }
    else{
      this.cancellationErrorMessage = "Please Select Atleast One Reason"
      this.cancelOrderErrorModal = true;
    }
    
  }
}
