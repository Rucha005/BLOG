import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { OrderSummeryRoutingModule } from './order-summery-routing.module';
import { OrderSummeryComponent } from './order-summery/order-summery.component';
import { SearchPipe } from './order-summery/pipe';
import { FormsModule } from '@angular/forms';
import { MyDatePickerModule } from 'mydatepicker';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
  imports: [
    CommonModule,
    OrderSummeryRoutingModule, FormsModule, MyDatePickerModule, NgxPaginationModule
  ],
  declarations: [OrderSummeryComponent, SearchPipe]
})
export class OrderSummeryModule { }
