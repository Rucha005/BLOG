import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { error } from 'selenium-webdriver';
import 'rxjs/add/operator/catch';
import { HttpHeaders } from '@angular/common/http';
import { AllServices } from '../../common/allservices.services';

@Injectable()
export class OrderSummeryService {
  public levelId : number;
  collectionName : string; 

  constructor( private http:Http,) { }
  
  //display seller order summery with dates
  displayOrdersSelectingDates(fromDate,toDate){
    let headers = new Headers ({});
    return this.http.get( AllServices.displayOrdersSelectingDates+"?page="+0+"&size="+100+"&fromDate="+fromDate+"&toDate="+toDate
    ).map((response: Response) =>  response.json());
  }
  //display all seller order summery
  displayAllOrders(){
    return this.http.get( AllServices.displayAllOrders+"?page="+0+"&size="+100
    ).map((response: Response) =>  response.json());
  
  } 
}