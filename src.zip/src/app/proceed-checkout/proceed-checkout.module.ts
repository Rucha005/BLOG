import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProceedCheckoutRoutingModule } from './proceed-checkout-routing.module';
import { ProceedCheckoutComponent } from './proceed-checkout/proceed-checkout.component';

@NgModule({
  imports: [
    CommonModule,
    ProceedCheckoutRoutingModule
  ],
  declarations: [ProceedCheckoutComponent],
  exports:[ProceedCheckoutComponent]
})
export class ProceedCheckoutModule { }