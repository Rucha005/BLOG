import { ProductCartModule } from './product-cart.module';

describe('ProductCartModule', () => {
  let productCartModule: ProductCartModule;

  beforeEach(() => {
    productCartModule = new ProductCartModule();
  });

  it('should create an instance', () => {
    expect(productCartModule).toBeTruthy();
  });
});
