export class Cart {
  constructor( 
        public cartId: number,
        public customerId: number,
        public rentTransactionId: number,
        public modelId: number,
        public rent: number,
        public priceAfterOffer: number,
        public productQuantity: number,
        public deliveryPinCode: number,
        public fromdate: string,
        public todate: string       
       ) { }
}