import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RatingRoutingModule } from './rating-routing.module';
import { RatingComponent } from './rating/rating.component';
import { ReactiveFormsModule } from '@angular/forms';
import { NgbModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { RatingService } from '../common/rating.service';
@NgModule({
  imports: [
    CommonModule,
    RatingRoutingModule, ReactiveFormsModule, NgbModule.forRoot()
  ],
  declarations: [RatingComponent],
  providers:[RatingService],
  exports:[RatingComponent]
})
export class RatingModule { }
