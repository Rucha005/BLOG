import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { environment } from '../../../environments/environment';
import { RatingService } from '../../common/rating.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'app-rating',
  templateUrl: './rating.component.html',
  styleUrls: ['./rating.component.css']
})

export class RatingComponent implements OnInit {
  rentOrderId: any;
  ReviewErrorMessage: string;
  public id;
  public description;
  public selected = 0;
  hovered = 0;
  ReviewForm: FormGroup;
  productid: number;
  customerid: number;
  reviewType: string;
  ReviewMessage= null;
  @Output() eventReviewSubmit = new EventEmitter<boolean>();

  constructor(private router :Router,private fb: FormBuilder,private ratingservice:RatingService,private spinnerService: Ng4LoadingSpinnerService) { 
    this.ReviewForm = this.fb.group({
      'reviewId':[null,Validators.required],
      'reviewTitle':[null,Validators.required],
      'type':['',Validators.required],
      'modelId':['', Validators.required],
      'customerId':['', Validators.required],
      'orderId':['',Validators.required],
      'stars':['', Validators.required],
      'reviewText':['', Validators.required],
     })
  }
  ngOnInit() {}
  reviewtype(value){
   this.reviewType = value;
  }
  submitReview(){
    this.productid= this.ratingservice.getReviewproductId()
    this.customerid = this.ratingservice.getReviewcustomerId()
    this.rentOrderId = this.ratingservice.getReviewrentOrderId()
    if(this.reviewType == null){
      this.ReviewForm.controls["type"].setValue ('Review');
    }
    else
    {
      this.ReviewForm.controls["type"].setValue (this.reviewType);
    }  
      this.ReviewForm.controls["modelId"].setValue (this.productid);
      this.ReviewForm.controls["customerId"].setValue (this.customerid);
      this.ReviewForm.controls["orderId"].setValue (this.rentOrderId);
      if(this.ReviewForm.controls["stars"].valid){
        this.spinnerService.show();   
        this.ratingservice.ReviewProduct(JSON.stringify(this.ReviewForm.value))
        .subscribe(response => 
        {
          this.spinnerService.hide();   
          this.ReviewMessage = "Thank you.Your review has been saved"; 
          this.ReviewForm.reset();
          this.eventReviewSubmit.emit(true);
          this.removeItems();
        },
        (error)=>{
          this.spinnerService.hide();   
        });
      }else{
        this.ReviewErrorMessage = "Please fill in all required fields";
        this.removeItems();
      }   
  }
  removeItems(){
    setTimeout(function() {
      this.ReviewMessage =null;
      this.ReviewErrorMessage = null;
    }.bind(this),environment.errorTimeoutms);
  }
}