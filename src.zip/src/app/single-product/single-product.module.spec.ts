import { SingleProductModule } from './single-product.module';

describe('SingleProductModule', () => {
  let singleProductModule: SingleProductModule;

  beforeEach(() => {
    singleProductModule = new SingleProductModule();
  });

  it('should create an instance', () => {
    expect(singleProductModule).toBeTruthy();
  });
});
