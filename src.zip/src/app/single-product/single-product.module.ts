import { ContactUsService } from './../contactus/contactus/contactus.service';
import { RatingService } from './../common/rating.service';
import { AllServices } from './../common/allservices.services';
import { LevelDataService } from './../common/levelData.service';
import { RegistartionService } from './../common/registartion.service';
import { ProductService } from './../common/product.service';
import { ProductCartService } from './../product-cart/product-cart/product-cart.service';
import { DialogService } from 'ng2-bootstrap-modal';
import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { SingleProductRoutingModule } from './single-product-routing.module';
import { SingleProductComponent } from './single-product/single-product.component';
import { WishlistModule } from '../wishlist/wishlist.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgxGalleryModule } from 'ngx-gallery';
import { MyDatePickerModule } from 'mydatepicker';
import { ProductCartModule } from '../product-cart/product-cart.module';
import { NgxSlideshowModule } from 'ngx-slideshow';
import { BreadcrumbService } from '../common/breadcrumb.service';
import { ProceedCheckoutModule } from '../proceed-checkout/proceed-checkout.module';

@NgModule({
  imports: [
    CommonModule,
    SingleProductRoutingModule, 
    NgxSlideshowModule,
    WishlistModule, 
    ReactiveFormsModule, 
    NgxGalleryModule, 
    MyDatePickerModule,
    WishlistModule, 
    FormsModule, 
    ProductCartModule,
    ProceedCheckoutModule
  ],
  declarations: [SingleProductComponent],
  providers:[
    BreadcrumbService,
    DatePipe,
    DialogService,
    RatingService,
    ProductService,
    ProductCartService,
    RegistartionService,
    LevelDataService,
    AllServices,
    ContactUsService
  ]
})
export class SingleProductModule { }
