import { LOCAL_STORAGE , WINDOW} from '@ng-toolkit/universal';
import * as moment from 'moment';
import { Component, OnInit,Input,ViewChild, ElementRef, AfterViewInit,Output,EventEmitter,HostListener, Renderer2, Inject} from '@angular/core';
import { Http } from '@angular/http';
import { RouterModule, ActivatedRoute, Router} from '@angular/router';
import { FormGroup, FormBuilder,Validators,FormControl, FormsModule} from '@angular/forms';
import { IMyDpOptions, IMyDate,IMyOptions, IMyDateModel, IMyDateRange, IMyDefaultMonth} from 'mydatepicker';
import { Location, isPlatformBrowser, DatePipe } from '@angular/common';
import { NgxGalleryOptions, NgxGalleryImage } from 'ngx-gallery';
import { Products, rentCartItemOffers } from '../../products/products/products';
import { ErrorStatus } from '../../common/ErrorStatus';
import { LevelOneData } from '../../header/header/allLevel';
import { ProductService } from '../../common/product.service';
import { ProductCartService } from '../../common/product-cart.service';
import { LoginService } from '../../login/login/login.service';
import { RegistartionService } from '../../common/registartion.service';
import { LevelDataService } from '../../common/levelData.service';
import { BreadcrumbService } from '../../common/breadcrumb.service';
import { RatingService } from '../../common/rating.service';
import { environment } from '../../../environments/environment';
import { ContactUsService } from '../../contactus/contactus/contactus.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { PLATFORM_ID } from '@angular/core';


@Component({
  selector: 'app-single-product',
  templateUrl: './single-product.component.html',
  styleUrls: ['./single-product.component.css']
})

export class SingleProductComponent implements OnInit 
{
  cartitems: any;
  name: any;
  errormessage: string;
  successmessage: string;
  comingsoonmodal: boolean;
  wishlistflags: boolean;
  show: boolean = true;
  showWishlistModal: boolean;
  showCartModal: boolean;
  showDateModal: boolean;
  showOfferModal: boolean;
  static today = new Date();
  selectedFromDate = new Date();
  singleItem: Products;
  imageList:any;
  filterData: any;
  id: any;
  errorMessage: any = '';
  errorStatus: ErrorStatus;
  dateErrorMessage = null;
  cartErrorMessage= null;
  OfferMessage=null;
  cartErrorMessages=null;
  transactionId: any;
  offerData: any;
  levelOneData: LevelOneData[] ;
  customerId:number;
  displayProductFlag= false;
  items: Products[] = [];
  pagedItems: Products[] = [];
  rentableStockQuantity :number;
  percentageOffer: any;
  percentage: number;
  breadcrumb:LevelOneData;
  selDate: IMyDate = {year: 0, month: 0, day: 0};
  galleryOptions: NgxGalleryOptions[];
  galleryImages: NgxGalleryImage[] = [];
  isFromDateSet: boolean;
  isToDateSet: boolean;
  leveloneid:number;
  levelFour:string;
  levelOne: any;
  v = 3;
  productPadding:any ;
  cardsize = "300px";
  alreadyBookedDatesArray : any[];
  @ViewChild('description') description: ElementRef;
  @ViewChild('datepickers') datepickers: ElementRef;
  score : number = 0;
  displayRatingScore = 4;
  reviewdata: any;
  contactForm: FormGroup;
  selectedDate: any;
  dateErrorMessage1: string;


  constructor(@Inject(PLATFORM_ID) private platformId,@Inject(WINDOW) private window: Window, @Inject(LOCAL_STORAGE) private localStorage: any, private renderer : Renderer2,private datePipe: DatePipe,
              private fb: FormBuilder,private productService: ProductService,private cartService:ProductCartService,private spinnerService: Ng4LoadingSpinnerService,
              private route: ActivatedRoute,private router: Router,private loginService :LoginService,private http : Http,private formBuilder: FormBuilder,
              private location:Location,private registrationservice: RegistartionService,private ratingservice: RatingService,
              private breadcrumbService: BreadcrumbService,private leveldataservice: LevelDataService,private mailService: ContactUsService) 
  {    
      this.loginService.isLoggedIn();
 
      /** Responsive latest product slider */
     if( isPlatformBrowser(this.platformId))
     {
      if(this.window.innerWidth <= 600)
      {
        this.v = 1;
        this.productPadding = "0px";
        this.cardsize = "280px";
      }
      else 
      if(this.window.innerWidth <= 800)
      {
        this.v = 2;
        this.productPadding = "0px";
      }
      else
      {
        this.v = 3;
        this.productPadding ="0px";
      }
     }

     this.myForm = this.fb.group({
        myDate: [null, Validators.required]
      });


      this.contactForm = this.fb.group({
        'firstName':['',Validators.required],
        'lastName':['',Validators.required],
        'email':['',Validators.required],
        'mobileNumber':['',Validators.required],
       })
  }
  closeModal(){
    this.showOfferModal = false;
    this.showDateModal = false;
    this.showCartModal = false;
    this.comingsoonmodal = false;
  }
  public myForm: FormGroup;
  closeDateModal() : any{
    this.showDateModal = false;
    this.myForm.reset();
    this.myForm.patchValue({myDate: null}); 

  }
  closeWishlistModal(){
    this.showWishlistModal = false;
    this.datepickers.nativeElement.focus();
  }
  get LoginService(){
    return this.loginService;
  }
  /** focus to description tab */
  focusKeywordsInput(){
    this.description.nativeElement.focus();
  }
  /** load all product data, load product images*/
  ngOnInit() 
  {
    this.route.params.subscribe(val => {
      this.id = val.id;
      this.transactionId = val.transactionId; 
    });
    this.getAllMenuLevels();
    this.getBreadCrumb();
    if(this.loginService.isLoggedIn()){
      this.getByUsername();
    }else{
      this.getRelatedProductsWithoutLogin();
      this.customerId = 0;
      this.items = this.cartService.loadAllCartFromLocalStorage();
      if(this.items){
        for(let product =0; product< this.items.length;product++){
          if(this.items[product].modelId == this.id){
            this.singleItem = this.items[product];
            this.displayProductFlag = true;
          }
        }
      }   
      if(this.displayProductFlag == false){
        this.loadModelDetailsById(); 
      }
    }
    this.loadProductFilterDetailsById()
    this.getReviewByProductId();
    this.loadProductImages();
    this.galleryOptions = [
    {
        width: '340px',
        height: '500px',
        thumbnailsColumns: 3
      }
    ];
    this.alreadyBookedDatesArray = [{
        begin : {year:1, month:1, day:1 },
        end : {year:SingleProductComponent.today.getFullYear(), month:SingleProductComponent.today.getMonth()+1, day:SingleProductComponent.today.getDate()+1 }
    }] ;
  }

  /** display related products */
  loadAllOtherProducts()
  { 
    this.spinnerService.show();   
    this.productService.getRelatedProduct(this.id, this.customerId).subscribe(items => {
      this.spinnerService.hide();    
      this.pagedItems = items;
      //console.log(JSON.stringify(this.pagedItems))
    },(error) =>{   
      this.spinnerService.hide();   
      this.pagedItems = null; this.errorStatus = JSON.parse(error._body); 
    });  
  }

  getRelatedProductsWithoutLogin()
  {
    this.spinnerService.show();   
    this.productService.getRelatedProduct(this.id, 0).subscribe(items => {
      this.spinnerService.hide();    
      this.pagedItems = items;
      for(let i=0; i<this.pagedItems.length; i++){
        //console.log(this.pagedItems[i].modelName)
      }
      this.cartitems = this.cartService.loadAllCartFromLocalStorage();
      for(let p=0; p<this.pagedItems.length; p++ ){
          if(this.cartitems){
              for(let product=0; product< this.cartitems.length;product++){
                  if(this.cartitems[product].modelId == this.pagedItems[p].modelId){
                    this.pagedItems[p].cartType = this.cartitems[product].cartType;
                  }
              }
          } 
      }
    },(error) =>{   
      this.spinnerService.hide();   
      this.pagedItems = null; this.errorStatus = JSON.parse(error._body); 
    });
  }
  /** get breadcrumb data */
  getBreadCrumb()
  {
    //debugger
    if( this.localStorage.getItem('levelFour') )
    {
      this.levelFour= this.localStorage.getItem('levelFour');
      if( this.localStorage.getItem('levelOne') )
      {
        this.levelOne = this.localStorage.getItem('levelOne');

        this.spinnerService.show();   
        this.breadcrumbService.getLevelFourBreadcrumb(this.levelFour)
        .subscribe(s => 
        {
          this.spinnerService.hide();   
          this.breadcrumb = s;
          //console.log("breadcrumb: " + JSON.stringify(this.breadcrumb)); 
        },
        (error) =>
        {  
          this.spinnerService.hide();   
        }); 
      }
    }
  } 

  /** related product navigation to same page */
  NavigateProducts(event,modelId,rentTransactionId)
  {
    this.router.navigate(['/product/', modelId ,rentTransactionId])
    this.ngOnInit(); 
  } 

  /** get all product images */
  loadProductImages()
  {
    this.galleryImages.splice(0,this.galleryImages.length)
    this.productService.getAllProductImages(this.id)
    .then(
      posts => 
    {
        this.imageList = posts;
        this.loadImages();
    },
    error => this.errorMessage = <any> error);
  }
  
  /** load product images to display into slider (thumbnail and big) */
  loadImages(){
    for(let i=0; i<this.imageList.thumbnail.length; i++){
      let obj = {
        small: this.imageList.thumbnail[i],
        medium: this.imageList.productDetails[i],
        big: this.imageList.productDetails[i],
      }
      this.galleryImages.push(obj);
    }
  } 
  /** display all product details */
  loadModelDetailsById() {
    this.spinnerService.show();   
    this.productService.getProductDetailsById(this.id, this.transactionId, this.customerId)
    .then(
      items => 
      { 
        this.spinnerService.hide();   
        this.singleItem=null;
        this.singleItem = items ;
        this.singleItem.modelDescription = items.modelDescription; 
        this.singleItem.deposit = items.deposit;
        this.singleItem.levelId = this.localStorage.getItem('levelOne');
        this.singleItem.levelName = 'levelOne';
        this.singleItem.productQuantity = 1;

        let wishlistflag = 'false';
        let cartflag = 'false';

        if(this.localStorage.getItem('moveFromWishlistFlag'))
          wishlistflag  = this.localStorage.getItem('moveFromWishlistFlag');
        
        if( this.localStorage.getItem('moveFromCartFlag') )
          cartflag= this.localStorage.getItem('moveFromCartFlag');

        if(wishlistflag == 'true' || cartflag == 'true')
        {
         this.showWishlistModal = true;
         this.localStorage.removeItem('moveFromWishlistFlag');
         this.localStorage.removeItem('moveFromCartFlag');
        }
        this.loadProductFilterDetailsById();
      },
      error => 
      {
        this.spinnerService.hide();   
        this.errorMessage = <any> error});       
  } 

  /** display product filters and specifications */
  loadProductFilterDetailsById() {
    let today = new Date();
    let alreadyBookedDatesArray : any[] = 
    [{
      begin : {year:1, month:1, day:1 },
      end : {year:today.getFullYear(), month:today.getMonth()+1, day:today.getDate()+1 }
    }] ;
    this.spinnerService.show();   
    this.productService.getModelFilterById(this.id , this.transactionId)
    .subscribe(items => { 
      this.spinnerService.hide();   
      this.filterData = items; 
      let beginDate : Date;
      let endDate : Date;
      for(let i=0; i<this.filterData.BookedDates.length; ++i)
      {
        let date = 
        {
          begin : {year:0, month:0, day:0 },
          end : {year:0, month:0, day:0 }
        }
        beginDate = new Date(this.filterData.BookedDates[i].bookingFromDate);
        if( i>0 )
        {
          let now = moment();
          var a = moment(beginDate,'YYYY/M/D');
          var b = moment(endDate,'YYYY/M/D');
          var diffDays = b.diff(a, 'days');
          if( Math.abs(diffDays) <= 2)
            beginDate = endDate;
        }
        date.begin.day =  beginDate.getDate();
        date.begin.month =  beginDate.getMonth()+1;
        date.begin.year = beginDate.getFullYear();
        endDate = new Date(this.filterData.BookedDates[i].bookingToDate);
        date.end.day =  endDate.getDate();
        date.end.month =  endDate.getMonth()+1;
        date.end.year = endDate.getFullYear();
        alreadyBookedDatesArray.push(date);
      }
      this.fromDateSelectionConstraint=
      {
          dateFormat: 'yyyy-mm-dd',
          sunHighlight: true,
          todayBtnTxt: 'Today',
          disableDateRanges: alreadyBookedDatesArray
      };
      this.toDateSelectionConstraint=
      {
          dateFormat: 'yyyy-mm-dd',
          sunHighlight: true,
          todayBtnTxt: 'Today',
          disableDateRanges: alreadyBookedDatesArray
      };
      //disableWeekends	false	Disable weekends (Saturday and Sunday).
    },(error)=>{
      this.spinnerService.hide();   
    });
  }
  /** calculate rent with cash offers */
  getPercentage(singleItem: Products)
  {
    if(singleItem.rentCartItemOffers.length > 0){
      for(let  c of singleItem.rentCartItemOffers){
        if(c.groupNo == 0){
          this.percentage = c.percentageOffer
          break;
        }else {
          this.percentage = 0;
        }
      }
      return this.percentage;
    }
  } 
  /** load Offer data */
  loadOfferData() 
  {
    this.spinnerService.show();   
    this.productService.loadOfferData( this.transactionId). subscribe(s => { 
      this.spinnerService.hide();   
      this.offerData= s;
    },(error)=>{
      this.spinnerService.hide();   
    });
  }
  /** get level four menus for display other categories */
  getAllMenuLevels()
  {
    this.spinnerService.show();   
    this.leveldataservice.getLevelOneAll()
    .subscribe(items => { 
      this.spinnerService.hide();   
      this.levelOneData = items; 
      for(let i=0; i<this.levelOneData.length; ++i){
        this.leveldataservice.getLevelTwoAllById(this.levelOneData[i].levelOneId)
        .subscribe(levelTwoItems => {
          this.levelOneData[i].levelTwo = levelTwoItems;
          for(let j=0; j<this.levelOneData[i].levelTwo.length; ++j){
            this.leveldataservice.getLevelThreeAllById(this.levelOneData[i].levelTwo[j].levelTwoId)
            .subscribe(levelThreeItems => { 
              this.levelOneData[i].levelTwo[j].levelThree = levelThreeItems;
              for(let k=0; k<this.levelOneData[i].levelTwo[j].levelThree.length ; ++k){
                this.leveldataservice.getLevelFourAllById(this.levelOneData[i].levelTwo[j].levelThree[k].levelThreeId)
                .subscribe(levelFourItems => {
                  this.levelOneData[i].levelTwo[j].levelThree[k].levelFour = levelFourItems;
                })
              }
            });
          }
        });
      }
    },(error)=>{
      this.spinnerService.hide();   
    });
  }
  /** get customer name after login */
  getByUsername() 
  {
    if( this.localStorage.getItem('currentUser') )
    {
      const currentUser = JSON.parse(this.localStorage.getItem('currentUser'));
      if (currentUser) 
      {
        this.spinnerService.show();   
        this.registrationservice.getByUsername(currentUser.username)
        .subscribe(c => 
        {
          this.spinnerService.hide();   
          this.customerId = c.userId 
          this.loadModelDetailsById();
          this.loadAllOtherProducts();
        },
        (error)=>
        {
          this.spinnerService.hide();   
        });
      }
    }
  }
  
  /** set fromdate and todate constraint */
  private fromDateSelectionConstraint: IMyOptions;
  private toDateSelectionConstraint: IMyOptions;
  private defaultMonth: IMyDefaultMonth;
  /** call when fromdate changed (disabled to date with conditions ) */
  public fromDateChanged(selectedFromDate)
  {
    this.rentableStockQuantity = 0;
    this.selectedFromDate = selectedFromDate;
    let month = selectedFromDate.jsdate.getMonth()+1;
    if(month <= 9){
    // Set default month to selected from date of current year
      this.defaultMonth = {
        defMonth: '0' + month + '/' + selectedFromDate.jsdate.getFullYear()
      }; 
    }else{
      this.defaultMonth = {
        defMonth: month + '/' + selectedFromDate.jsdate.getFullYear()
      }; 
    }
    if( selectedFromDate.jsdate == null )
    {
      this.isFromDateSet = false;
      let today = new Date();
      this.toDateSelectionConstraint=
      {
        dateFormat: 'yyyy-mm-dd',
        sunHighlight: true,
        todayBtnTxt: 'Today',
        disableUntil: { year: today.getFullYear(), month: today.getMonth()+1, day: today.getDate() }
      };
    } 
    else
    {
      this.isFromDateSet = true;
      this.singleItem.bookingFromDate = this.datePipe.transform(selectedFromDate.jsdate, 'dd-MMM-yyyy');

      this.toDateSelectionConstraint = 
      {
        dateFormat: 'yyyy-mm-dd',
        sunHighlight: true,
        todayBtnTxt: 'Today',
        //disableUntil: { year: selectedFromDate.jsdate.getFullYear(), month:  selectedFromDate.jsdate.getMonth()+1, day:  selectedFromDate.jsdate.getDate()+this.singleItem.durationUnit-2 }
        disableUntil: { year: selectedFromDate.jsdate.getFullYear(), month:  selectedFromDate.jsdate.getMonth()+1, day:  selectedFromDate.jsdate.getDate()}
      };
    
      if( this.isToDateSet == true )
      {
        this.getRentableStockQuantity();
      }
    }
  }
  /** call when todate changed (disabled from date with conditions )*/
  public toDateChanged(selectedToDate)
  {
    this.rentableStockQuantity = 0;
    //this.selectedDate = selectedToDate;
    if( selectedToDate.jsdate == null )
    {
      let date = new Date();
      this.isToDateSet = false;
      this.fromDateSelectionConstraint = {
        dateFormat: 'yyyy-mm-dd',
        disableSince: { year: 0, month:  0, day:  0 }
      };
    }
    else 
    {
      this.isToDateSet = true;
      this.singleItem.bookingToDate = this.datePipe.transform(selectedToDate.jsdate, 'dd-MMM-yyyy');

      this.fromDateSelectionConstraint = {
        dateFormat: 'yyyy-mm-dd',
        disableSince: { year: selectedToDate.jsdate.getFullYear(), month:  selectedToDate.jsdate.getMonth()+1, day:  selectedToDate.jsdate.getDate()+this.singleItem.durationUnit-2 }
      };
      if( this.isFromDateSet == true )
      {
        this.getRentableStockQuantity();
      }
    }
  }

  /** get rentable stock quantity and discount applied offer & calculate days (todate-fromdate)*/
  private getRentableStockQuantity()
  {
    this.OfferMessage =null;
    let fdate = this.datePipe.transform(this.singleItem.bookingFromDate, 'yyyy-MM-dd');
    let tdate = this.datePipe.transform(this.singleItem.bookingToDate, 'yyyy-MM-dd');
    let fromdate= new Date(this.datePipe.transform(fdate, 'dd-MMMM-yyyy')); 
    let todate= new Date(this.datePipe.transform(tdate, 'dd-MMMM-yyyy'));   
    let diffc = todate.getTime() - fromdate.getTime();
    let days = Math.round(Math.abs(diffc/(1000*60*60*24)))+1;
    this.singleItem.days = days;
    if(days >= 30){
      this.singleItem.bookingToDate = null;
      fromdate = null;
      tdate = null;
      this.dateErrorMessage = "You have selected more than 30 days to rent this product.If you want to rent for more than 30 days please contact us for better pricing!"
      this.showDateModal=true;
      this.removeErrorMessage();
      //return;
    }  
    if(days == this.singleItem.durationUnit){
      this.dateErrorMessage1 = "Renting Period is less than 3 days so additional charges will be applied."
      this.showDateModal=true;
      this.removeErrorMessage()
      //return;
    }  
    if(this.singleItem.rentCartItemOffers.length > 0)
      this.singleItem.rentCartItemOffers.splice(0,this.singleItem.rentCartItemOffers.length)
      this.spinnerService.show();   
      this.productService.getDiscountandStockonBookingValues(this.id ,this.transactionId,fdate,tdate,this.levelOne)
      .subscribe(items => 
        {
          this.spinnerService.hide();   
          this.rentableStockQuantity = items.netRentableStock;  
          //console.log(JSON.stringify(items)); 
          if(items.percentageOffer.percentageOffer != null)
          { 
            this.percentageOffer = items.percentageOffer.percentageOffer;
            if(this.rentableStockQuantity == 0)
            {
              this.dateErrorMessage1 = this.singleItem.modelName+ " is unavailable."
              this.showDateModal=true;
              this.removeErrorMessage()
              return;
            } 
            if(this.percentageOffer > 0){
              this.OfferMessage = this.percentageOffer + "% Discount Applied";
              this.showOfferModal = true;
              this.singleItem.rentCartItemOffers.push(
                this.initRentCartItemOffersForm(items.percentageOffer.offerName,items.percentageOffer.offerId,items.percentageOffer.percentageOffer,items.percentageOffer.offerDescription,items.percentageOffer.groupNo)
              )
            }
          }
        },(error)=>{
          this.spinnerService.hide();   
        })
  }
  /** increased quantity of products */
  addQuantity() 
  {
    if (this.rentableStockQuantity == this.singleItem.productQuantity) {
      this.showCartModal = true;
      this.cartErrorMessage = "The requested quantity for " + this.singleItem.modelName + " is not available, Send request mail to rentout@voyagekart.com for additional quantity."
      // this.cartErrorMessages ="Send request mail to rentout@voyagekart.com for additional quantity."
      // this.removeErrorMessage();
      return
    }
    else {
      this.singleItem.productQuantity = this.singleItem.productQuantity +1;
    }
  }
  /** decreased quantity of products */
  removeQuantity() 
  {
    if (this.singleItem.productQuantity <= 1) 
    {
      return
    }
    else 
    {
      this.singleItem.productQuantity = this.singleItem.productQuantity - 1;
    }
  }
  /** remove error message after 5 seconds */
  removeErrorMessage() 
  {
        setTimeout(function() {
        // this.dateErrorMessage = null;
        // this.cartErrorMessage = null;
        // this.cartErrorMessages= null;
      }.bind(this),environment.errorTimeoutms);
  }
  initRentCartItemOffersForm(offerName,offerId,percentageOffer,offerDescription,groupNo) 
  {
      return new rentCartItemOffers(0,offerId,offerName,percentageOffer,offerDescription,groupNo);
  }
  getReviewByProductId()
  {
    this.spinnerService.show();   
    this.ratingservice.getReviewByProduct(this.id).subscribe(data=>{
      this.spinnerService.hide();   
      this.reviewdata = data;
      this.getavrageReviewcount();
    },(error)=>{
      this.spinnerService.hide();   
    })
  }
  getavrageReviewcount()
  {
    let rating =0;
    for(let i=0;i<this.reviewdata.length;i++){
      rating = rating +this.reviewdata[i].stars / this.reviewdata.length
    }
    return Number((rating).toFixed(1))
  }
  getcomingsoonmodal()
  {
    this.comingsoonmodal = true;
  }
  sendEmail(productid) 
  {
    let data = (JSON.stringify(this.contactForm.value));
    let modelid = productid;
    if(this.contactForm.controls['firstName'].valid && this.contactForm.controls['lastName'].valid && this.contactForm.controls['email'].valid && this.contactForm.controls['mobileNumber'].valid ){
      this.spinnerService.show();
      this.mailService.sendmailForComingSoonProduct(this.contactForm.value,modelid).subscribe(res => {
        this.spinnerService.hide();
        this.successmessage = "Your message has been send";
        this.contactForm.reset();
      },(error) => {
        this.spinnerService.hide();
        this.errormessage = "Sorry ,it seems that my mail server is not responding. Please try again later";
        this.contactForm.reset();
      })
    }else{
      this.errormessage = "Please fill in all required fields"
      this.remove();
    }  
  }
  remove()
  {
    setTimeout(function() {
      this.errormessage = null;
    }.bind(this), environment.errorTimeoutms);
  }
}
