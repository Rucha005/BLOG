import { LOCAL_STORAGE } from '@ng-toolkit/universal';
import {Component, OnInit, Inject} from '@angular/core';
import { Router } from '@angular/router';
import { Products } from '../../products/products/products';
import { FormArray, FormBuilder } from '@angular/forms';
import { ErrorStatus } from '../../common/ErrorStatus';
import { ProductCartService } from '../../common/product-cart.service';
import { ProductService } from '../../common/product.service';
import { LoginService } from '../../login/login/login.service';
import { RegistartionService } from '../../common/registartion.service';
import { DatePipe } from '@angular/common';
import { HeaderComponent } from '../../header/header/header.component';
import { environment } from '../../../environments/environment';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';


@Component({
  selector: 'app-view-cart',
  templateUrl: './view-cart.component.html',
  styleUrls: ['./view-cart.component.css']
})

//when login and localstorage data add into cart db
export class ViewCartComponent implements OnInit {
  cartError: any;
  index: any;
  servicecalled: boolean;
  items: Products[] = [];
  customerId: number;
  cart_form: FormArray;
  errorStatus: ErrorStatus;
  cartErrorMessage = null;
  specialPrice:number;
  rentPerDay: number;
  percentage: number;
  unAvailabelProductsErrorMessage = null;
  unAvailabelProducts:Products [] = [];

constructor(@Inject(LOCAL_STORAGE) private localStorage: any,private datePipe: DatePipe,private router: Router,private spinnerService: Ng4LoadingSpinnerService,
            private cartService: ProductCartService, private _fb: FormBuilder, private loginService: LoginService, 
            private productService: ProductService,private registrationservice: RegistartionService) 
{
  if (loginService.isLoggedIn()) 
  {
    this.getByUsername();
  }
  else 
  {
    this.items = JSON.parse(localStorage.getItem('cartData'));
  }
}
ngOnInit() 
{
  this.cart_form = this._fb.array([]);
}
/** Add to wishlist from cart*/
addToWishlist()
{
  if( this.localStorage.getItem('cartData') )
    this.items = JSON.parse(this.localStorage.getItem('cartData')) 
}
/* increase quantity */
addQuantity(cart: Products,itemsIndex) 
{
  if (this.loginService.isLoggedIn()) 
  {
    this.cartErrorMessage = null;
    this.addOrRemoveQuantityInDatabase(cart, 'add' ,itemsIndex)
    this.getSpecialPrice(cart);
  }
  else 
  {
    this.cartErrorMessage = null;
    this.addQuanityInLocalStorage(cart,itemsIndex);
    this.getSpecialPrice(cart);
  }
}
/* increase quantity in localstorage */
addQuanityInLocalStorage(cart: Products,itemsIndex) 
{
  if( this.localStorage.getItem('cartData') )
  {
    this.items = JSON.parse(this.localStorage.getItem('cartData'));
    for (let p = 0; p < this.items.length; p++) 
    {
      if (this.items[p].modelId == cart.modelId) 
      {
        if (this.items[p].netRentableStock == cart.productQuantity) 
        {
          this.index = itemsIndex;
          this.cartErrorMessage = "The requested quantity for " + cart.modelName + " is not available."
          this.removeErrorMessage();
          return;
        }
        this.items[p].productQuantity = cart.productQuantity + 1;
      }
    }
    this.localStorage.setItem('cartData', JSON.stringify(this.items));
  }
}

/* increase and remove quantity from database */
addOrRemoveQuantityInDatabase(cart: Products, opertion,itemsIndex) 
{
  if (opertion == 'add') 
  {
    if (cart.netRentableStock == cart.productQuantity) 
    {
      this.index = itemsIndex;
      this.cartErrorMessage = "The requested quantity for " + cart.modelName + " is not available."
      this.removeErrorMessage();
      return;
    }
  }
  else 
  if (opertion == 'subtract') 
  {
    if (cart.productQuantity == 0) 
    {
      this.index = itemsIndex;
      this.cartErrorMessage = "Please select at least 1  quantity for " + cart.modelName;
      this.removeErrorMessage();
      return
    }
  }

  this.spinnerService.show();   
  this.cartService.addOrRemoveQuantityInDatabase(cart.rentCartId, opertion)
  .subscribe(response => 
  {
     this.spinnerService.hide();   
     this.loadAllCartDataByCustomerId();
  },
  (error)=>
  {
    this.spinnerService.hide();   
  });
}
/* remove quantity */
removeQuantity(cart,itemsIndex) 
{
  this.cartErrorMessage = null;
  if (cart.productQuantity <= 1) 
  {
    return
  }
  if (this.loginService.isLoggedIn()) 
  {
    this.cartErrorMessage = null;
    this.addOrRemoveQuantityInDatabase(cart, 'subtract',itemsIndex)
  }
  else 
  {
    if( this.localStorage.getItem('cartData') )
    {
      this.items = JSON.parse(this.localStorage.getItem('cartData'));

      for (let p = 0; p < this.items.length; p++) 
      {
        if (this.items[p].modelId == cart.modelId) 
        {
          this.items[p].productQuantity = cart.productQuantity - 1;
        }
      }
      this.localStorage.setItem('cartData', JSON.stringify(this.items));
    }
  }
  this.getSpecialPrice(cart);
}
/* display all cart data by customer */
loadAllCartDataByCustomerId() 
{
  this.spinnerService.show();   
  this.cartService.loadAllCartDataByCustomerId(this.customerId).subscribe(s => 
  {
    this.spinnerService.hide();   
    this.items=s;
    HeaderComponent.cartData = this.items;
    this.cartItemCountFromDb();
  },
  (error) => 
  {
    this.spinnerService.hide();   
    this.errorStatus = JSON.parse(error._body);
    if (this.errorStatus.status = 404) 
    {
      HeaderComponent.cartCount = 0;
      this.cartError = this.errorStatus.errorMessage
    }
  });
}
/* calculate days todate-fromdate */
dayscal(cart: Products)
{
  var date=new Date(cart.bookingFromDate);
  var date1=new Date(cart.bookingToDate);
  let diffc = date1.getTime() - date.getTime();
  let days = Math.round(Math.abs(diffc/(1000*60*60*24)))+1;
  return days;  
}
/* get delivery date */
getDeliveryDate(cart : Products)
{
  var date=new Date(cart.bookingFromDate);
  var deliveryDate = new Date(date.getFullYear(),date.getMonth(), date.getDate() -1);
  cart.deliverydate = this.datePipe.transform(deliveryDate, 'dd-MMM-yyyy');  
  return cart.deliverydate;
}
/* get pickup date */
getPickupDate(cart : Products)
{
  var date=new Date(cart.bookingToDate);
  var pickupDate = new Date(date.getFullYear(),date.getMonth(), date.getDate() +1);
  cart.pickupdate = this.datePipe.transform(pickupDate, 'dd-MMM-yyyy');  
  return cart.pickupdate;
}

/* get user name and and load all cart data */
getByUsername() 
{
  if( this.localStorage.getItem('currentUser') )
  {
    var currentUser = JSON.parse(this.localStorage.getItem('currentUser'));
    if (currentUser) 
    {
      this.spinnerService.show();   
      this.registrationservice.getByUsername(currentUser.username)
      .subscribe(items => 
      {
        this.spinnerService.hide();   
        this.customerId = items.userId
        this.addLocalCartDataToDatabase();
        this.loadAllCartDataByCustomerId();
      },
      (error)=>
      {
        this.spinnerService.hide();   
      });
    }
  }
}
/* get cart total count */
get getCartCount() 
{
  if(this.loginService.isLoggedIn()) {
   return HeaderComponent.cartCount;
  }else{
   return this.cartService.countCartItems();
  } 
}
get WishListCount()
{
  if(this.loginService.isLoggedIn()) 
  {
    this.spinnerService.show();   
    this.cartService.cartItemCount(this.customerId,'WISHLIST').subscribe(s => 
    {
      this.spinnerService.hide();   
      return s.count;
    },
    (erorr)=>
    {
     this.spinnerService.hide();   
    });
   }
   else
   {
    return this.cartService.countCartItems();
   } 
  return this.cartService.wishListCount;
}
/* calculate discounted price */
getSpecialPrice(cart: Products)
{
  if(cart.rentCartItemOffers.length > 0){
    for(let  c of cart.rentCartItemOffers){
      if(c.groupNo == 0){
       this.specialPrice = (cart.rentPerDay - ((cart.rentPerDay * c.percentageOffer / 100)))* cart.productQuantity
        break;
      }else if(c.groupNo != 0) {
        this.specialPrice = cart.rentPerDay * cart.productQuantity;
      }
    }
    return this.specialPrice;
  }else if(cart.rentCartItemOffers.length == 0){
    return  cart.rentPerDay * cart.productQuantity;
  }
}
/* get total rent (rent * qauntity) */
getRent(cart:Products)
{
  if(cart.rentCartItemOffers.length > 0){
    for(let  c of cart.rentCartItemOffers){
      if(c.groupNo == 0){
        this.rentPerDay = cart.rentPerDay
        break;
      }else {
        this.specialPrice = cart.rentPerDay  * cart.productQuantity
      }
    }
    return this.rentPerDay;
  }
}
/* get percentage offer*/
getPercentage(cart: Products)
{
  if(cart.rentCartItemOffers.length > 0){
    for(let  c of cart.rentCartItemOffers){
      if(c.groupNo == 0){
        this.percentage = c.percentageOffer
        break;
      }else {
        this.percentage = 0;
      }
    }
    return this.percentage;
  }  
}
/* add local data to database */
addLocalCartDataToDatabase() 
{
  if (this.cartService.checkLocalStroageIsEmpty() == false) 
  {
    if( this.localStorage.getItem('cartData') )
    {
      this.items = JSON.parse(this.localStorage.getItem('cartData'))
      for (let i = 0; i < this.items.length; i++) 
      {
        if(this.items[i].rentCartItemOffers == null) 
        {
          this.cart_form.push(
            this.initForm(
              this.items[i].rentTransactionId,
              this.items[i].modelId,
              this.items[i].rentPerDay,
              (this.items[i].rentPerDay),
              this.items[i].productQuantity,
              this.items[i].bookingFromDate,
              this.items[i].bookingToDate,
              this.items[i].cartType,
              ((this.items[i].rentPerDay)* this.items[i].days),0))
        }
        else
        {
          if(this.items[i].rentCartItemOffers.length > 0) 
          {
            this.cart_form.push(
            this.initForm(
              this.items[i].rentTransactionId,
              this.items[i].modelId,
              this.items[i].rentPerDay,
              (this.items[i].rentPerDay-(this.items[i].rentPerDay * this.items[i].rentCartItemOffers[0].percentageOffer / 100)),
              this.items[i].productQuantity,
              this.items[i].bookingFromDate,
              this.items[i].bookingToDate,
              this.items[i].cartType,
              ((this.items[i].rentPerDay-(this.items[i].rentPerDay * this.items[i].rentCartItemOffers[0].percentageOffer / 100))* this.items[i].days),
              this.items[i].rentCartItemOffers[0].offerId))
          }
          else
          {
            this.cart_form.push(
            this.initForm(
              this.items[i].rentTransactionId,
              this.items[i].modelId,
              this.items[i].rentPerDay,
              (this.items[i].rentPerDay),
              this.items[i].productQuantity,
              this.items[i].bookingFromDate,
              this.items[i].bookingToDate,
              this.items[i].cartType,
              ((this.items[i].rentPerDay)* this.items[i].days),0))
          }
        }
      }

      this.spinnerService.show();   
      this.cartService.addCartDataToDatabase(this.cart_form.value)
      .subscribe(response => 
      {
        this.spinnerService.hide();   
        this.localStorage.removeItem('cartData')
        this.loadAllCartDataByCustomerId();
      },
      (error) => 
      {
        this.spinnerService.hide();   
      });
    }
  }
}
/* delete items(products) from cart */
removeItemFromCart(deleteProduct: Products) 
{
  if (this.loginService.isLoggedIn()) 
  {
    this.spinnerService.show();   
    this.cartService.removeCartFromDatabase(deleteProduct.rentCartId)
    .subscribe(() => 
    {
      this.spinnerService.hide();   
      this.loadAllCartDataByCustomerId();
    },
    (error) => 
    {
      this.spinnerService.hide();   
    })
  }
  else 
  {
    this.cartService.removeItemFromLocalCart(deleteProduct)
    if( this.localStorage.getItem('cartData') )
    {
      this.items = JSON.parse(this.localStorage.getItem('cartData'));
      HeaderComponent.cartData = this.items;
      HeaderComponent.cartCount = this.items.length;
      if (this.cartService.checkLocalStroageIsEmpty()) 
      {
        this.items = null;
        HeaderComponent.cartCount = 0
      }
    }
  }
}

cartItemCountFromDb() 
{
  this.spinnerService.show();   
  this.cartService.cartItemCount(this.customerId,'CART').subscribe(s => {
    this.spinnerService.hide();   
    HeaderComponent.cartCount = s.count;
  },(erorr)=>{
    this.spinnerService.hide();   
  });
}

initForm(rentTransactionId, modelId, rentPerDay, rentAfterOffer, productQuantity,bookingFromDate,bookingToDate,cartType,totalRent,offerId) 
{
  return this._fb.group({
      'cartId': [null],
      'customerId': [this.customerId],
      'rentTransactionId': [rentTransactionId],
      'modelId': [modelId],
      'rentPerDay': [rentPerDay],
      'rentAfterOffer': [rentAfterOffer],
      'productQuantity': [productQuantity],
      'deliveryPinCode': [411030],
      'bookingFromDate' :[bookingFromDate],
      'bookingToDate':[bookingToDate],
      'cartType':[cartType],
      'totalRent':[totalRent],
      'rentCartItemOffers': this._fb.array([
        this.initRentCartItemOffersForm(offerId)
	    ])
  });
}

initRentCartItemOffersForm(offerId) 
{
  return this._fb.group({
    'offerId' : offerId
  });
}

/* get deposite of products */
get getDeposit()
{
  let deposit =0;
  if (this.items.length > 0 || this.items != null) {
    for (let p = 0; p < this.items.length; p++) {
      if(this.items[p].availableFlag && this.items[p].cartType == 'CART'){
        deposit = deposit + (this.items[p].deposit) * this.items[p].productQuantity
       }
    }
  }
  return deposit;
}

/*calculate cart total */
get getAllProductTotal() 
{
    let grandTotal = 0;
    let actualPrice = 0;
    if (this.items.length > 0 || this.items != null) {
      for (let p = 0; p < this.items.length; p++) {
        if(this.items[p].availableFlag && this.items[p].cartType == 'CART'){
          grandTotal = grandTotal + ( this.getSpecialPrice(this.items[p])* this.dayscal(this.items[p]))
        }
      }
    }
    return grandTotal;
}

/*remove error message after 5 seconds */
removeErrorMessage() 
{
  setTimeout(function() {
  this.cartErrorMessage = null;
  }.bind(this),environment.errorTimeoutms);
}

selectiondate(cart){
  let modelid = cart.modelId;
  let renttransactionid =cart.rentTransactionId;
  this.removeItemFromCart(cart);
  this.router.navigate(['/product/', modelid ,renttransactionid]);  
}

/** navigate to product details page */
navigate(event,modelId,rentTransactionId,levelOneId,levelFourId){
  this.localStorage.removeItem('leveloneid');
  this.localStorage.setItem('levelOne',levelOneId);
  this.localStorage.setItem('levelFour',levelFourId);
  this.router.navigate(['/product/', modelId ,rentTransactionId])
  event.preventDefault();
  event.stopPropagation();
} 
}