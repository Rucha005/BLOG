import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ViewWishlistRoutingModule } from './view-wishlist-routing.module';
import { ViewWishlistComponent } from './view-wishlist/view-wishlist.component';

@NgModule({
  imports: [
    CommonModule,
    ViewWishlistRoutingModule
  ],
  declarations: [ViewWishlistComponent]
})
export class ViewWishlistModule { }
