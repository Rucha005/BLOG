import { LOCAL_STORAGE, WINDOW } from '@ng-toolkit/universal';
import { Component, OnInit, Input, Output, EventEmitter, Inject } from '@angular/core';
import { FormArray, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Products } from '../../products/products/products';
import { ErrorStatus } from '../../common/ErrorStatus';
import { LoginService } from '../../login/login/login.service';
import { ProductCartService } from '../../common/product-cart.service';
import { RegistartionService } from '../../common/registartion.service';
import { HeaderComponent } from '../../header/header/header.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.css']
})
export class WishlistComponent implements OnInit {

  customerId: any;
  items: Products[] = [];
  @Input() product: Products;
  @Output() addToWishListFlag = new EventEmitter;
  errorStatus: ErrorStatus;
  addToCartProduct: Products;
  private _Cartform: FormArray;

  constructor(@Inject(WINDOW) private window: Window, @Inject(LOCAL_STORAGE) private localStorage: any, private loginService: LoginService,
    private cartService: ProductCartService, private registrationservice: RegistartionService, private _fb: FormBuilder, private route: Router,
    private spinnerService: Ng4LoadingSpinnerService) {
    if (loginService.isLoggedIn()) {
      this.getByUsername();
    }
  }

  ngOnInit() {
    this._Cartform = this._fb.array([]);
  }

  get getWishlistCount() {
    if (this.loginService.isLoggedIn()) {
      return HeaderComponent.wishlistCount;
    }
    else {
      return this.cartService.countWithListItems();
    }
  }

  removeItemFromWishlist(product: Products) {

    //debugger
    if (this.loginService.isLoggedIn()) {

      // remove from wishlist item 
      for (let p = 0; p < this.items.length; p++) {
        if (this.items[p].rentTransactionId === product.rentTransactionId) {
            this.spinnerService.show();
            this.cartService.removeWishlistFromDatabase(this.customerId, product.rentTransactionId, product.modelId).subscribe(() => {
              this.spinnerService.hide();
              this.product.cartType = " ";
              product.isInWishlistFlag = false;
              this.addToWishListFlag.emit();
              //this.route.navigate(['product/'+this.product.modelId,this.product.rentTransactionId]);
              this.loadAllWishlistDataByCustomerId();
              this.window.location.reload();
            },
              (error) => {
                this.spinnerService.hide();
                this.errorStatus = JSON.parse(error._body);
                if (this.errorStatus.status = 404) {
                  HeaderComponent.wishlistCount = 0;
                }
              })
        }
      }
    }
    else {
      for (let p = 0; p < this.items.length; p++) {
        this.product.isInWishlistFlag = false;
        if (this.items[p].rentTransactionId === product.rentTransactionId) {
          if (this.items[p].modelId === product.modelId) {
            if (this.items[p].cartType == "WISHLIST") {
              this.items[p].cartType = " ";
              this.product.cartType = " ";
              this.items.splice(p, 1);
              this.addToWishListFlag.emit();
              this.localStorage.setItem('cartData', JSON.stringify(this.items));
              //this.route.navigate(['product/'+this.product.modelId,this.product.rentTransactionId]);
              this.window.location.reload();
              break;
            }
          }  
        }
      }
    }
  }

  addToWishList() {
    if (this.loginService.isLoggedIn()) {
      if (this.product.bookingFromDate == null || this.product.rentCartId == null) {
        this.addToWishlistToDatabase(this.product)
        if (this.product.cartType = "WISHLIST") {
          this.product.isInWishlistFlag = false;
          this.removeItemFromWishlist(this.product);
          this.addToWishListFlag.emit();
          this.route.navigate(['product/' + this.product.modelId, this.product.rentTransactionId]);
        }
      }
      else {
        if (this.product.cartType = "CART") {
          this.product.cartType = "WISHLIST"
          this.spinnerService.show();
          this.cartService.moveDataToWishlistOrCart(this.product.rentCartId, this.product.cartType).subscribe(s => {
            this.spinnerService.hide();
            this.product.isInWishlistFlag = true;
            this.loadAllWishlistDataByCustomerId();
            this.addToWishListFlag.emit();
          },
            (error) => {
              this.spinnerService.hide();
              this.errorStatus = JSON.parse(error._body);
              if (this.errorStatus.status = 404) {
                HeaderComponent.cartCount = 0;
              }
            })
        }
        else {
          this.product.cartType = "CART";
          this.spinnerService.show();
          this.cartService.moveDataToWishlistOrCart(this.product.rentCartId, this.product.cartType).subscribe(s => {
            this.spinnerService.hide();
            this.product.isInWishlistFlag = true;
            this.addToWishListFlag.emit();
            this.loadAllWishlistDataByCustomerId();
          },
            (error) => {
              this.spinnerService.hide();
            })
        }
      }
    }
    else {
      debugger
      this.product.productInUserCartFlag = true;
      if (this.localStorage.getItem('cartData')) 
      {
        this.items = JSON.parse(this.localStorage.getItem('cartData'))
        if (this.items.length > 0) 
        {
          for (let p = 0; p < this.items.length; ++p) 
          {
            if (this.items[p].rentTransactionId === this.product.rentTransactionId && 
                this.items[p].modelId === this.product.modelId) 
            {
              if (this.product.cartType == "WISHLIST") {
                this.product.isInWishlistFlag = false;
                this.removeItemFromWishlist(this.product);
                this.addToWishListFlag.emit();
                break;
              }
              else if (this.product.cartType == "CART") {
                this.items[p].cartType = "WISHLIST";
                this.items.push(this.product);
                this.localStorage.setItem('cartData', JSON.stringify(this.items));
                this.product.isInWishlistFlag = true;
                this.addToWishListFlag.emit();
                break;
              }
            }
          }
            this.product.cartType = "WISHLIST"
            this.items.push(this.product);
            this.localStorage.setItem('cartData', JSON.stringify(this.items));
            this.product.isInWishlistFlag = true;
            this.addToWishListFlag.emit();
        }
        else {
          this.product.cartType = "WISHLIST"
          this.items.push(this.product);
          this.localStorage.setItem('cartData', JSON.stringify(this.items));
          this.product.isInWishlistFlag = true;
          this.addToWishListFlag.emit();
        }
      }
      else 
      {
        this.product.cartType = "WISHLIST"
        this.items.push(this.product);
        this.localStorage.setItem('cartData', JSON.stringify(this.items));
        this.product.isInWishlistFlag = true;
        this.addToWishListFlag.emit();
      }
    }
  }

  getByUsername() {
    if (this.localStorage.getItem('currentUser')) {
      var currentUser = JSON.parse(this.localStorage.getItem('currentUser'));
      if (currentUser) {
        this.spinnerService.show();
        this.registrationservice.getByUsername(currentUser.username)
          .subscribe(items => {
            this.spinnerService.hide();
            this.customerId = items.userId
            this.loadAllWishlistDataByCustomerId();
          },
            (error) => {
              this.spinnerService.hide();
            });
      }
    }
  }

  loadAllWishlistDataByCustomerId() {
    this.spinnerService.show();
    this.cartService.loadAllWishlistDataByCustomerId(this.customerId)
      .subscribe(s => {
        this.spinnerService.hide();
        this.items = s;
        HeaderComponent.wishlistCount = this.items.length;
      },
        (error) => {
          this.spinnerService.hide();
          this.errorStatus = JSON.parse(error._body);
          if (this.errorStatus.status = 404) {
            HeaderComponent.wishlistCount = 0;
          }
        });
  }

  addToWishlistToDatabase(product: Products) {
    product.cartType = "WISHLIST";
    this.addToCartProduct = product;
    product.productInUserCartFlag = true;
    this.product.availableFlag = true;
    if (this.product.rentCartItemOffers == null) {
      this._Cartform.push(
        this.initForm(
          this.product.rentTransactionId,
          this.product.modelId,
          this.product.rentPerDay,
          (this.product.rentPerDay - (this.product.rentPerDay * this.product.percentageOffer / 100)),
          this.product.productQuantity,
          this.product.bookingFromDate,
          this.product.bookingToDate,
          this.product.cartType,
          ((this.product.rentPerDay - (this.product.rentPerDay * this.product.percentageOffer / 100)) * this.product.days), 0))
    }
    else
      if (this.product.rentCartItemOffers.length > 0) {
        this._Cartform.push(
          this.initForm(
            this.product.rentTransactionId,
            this.product.modelId,
            this.product.rentPerDay,
            (this.product.rentPerDay - (this.product.rentPerDay * this.product.percentageOffer / 100)),
            this.product.productQuantity,
            this.product.bookingFromDate,
            this.product.bookingToDate,
            this.product.cartType,
            ((this.product.rentPerDay - (this.product.rentPerDay * this.product.percentageOffer / 100)) * this.product.days),
            this.product.rentCartItemOffers[0].offerId))
      }
      else {
        this._Cartform.push(
          this.initForm(
            this.product.rentTransactionId,
            this.product.modelId,
            this.product.rentPerDay,
            (this.product.rentPerDay - (this.product.rentPerDay * this.product.percentageOffer / 100)),
            this.product.productQuantity,
            this.product.bookingFromDate,
            this.product.bookingToDate,
            this.product.cartType,
            ((this.product.rentPerDay - (this.product.rentPerDay * this.product.percentageOffer / 100)) * this.product.days), 0))
      }

    this.spinnerService.show();
    this.cartService.addCartDataToDatabase(this._Cartform.value)
      .subscribe(response => {
        this.spinnerService.hide();
        this.localStorage.removeItem('cartData')
        this.loadAllWishlistDataByCustomerId();
      },
        (error) => {
          this.spinnerService.hide();
        });
  }

  initForm(rentTransactionId, modelId, rentPerDay, rentAfterOffer, productQuantity, bookingFromDate, bookingToDate, cartType, totalRent, offerId) {
    return this._fb.group(
      {
        'cartId': [null],
        'customerId': [this.customerId],
        'rentTransactionId': [rentTransactionId],
        'modelId': [modelId],
        'rentPerDay': [rentPerDay],
        'rentAfterOffer': [rentAfterOffer],
        'productQuantity': [productQuantity],
        'deliveryPinCode': [411030],
        'bookingFromDate': [bookingFromDate],
        'bookingToDate': [bookingToDate],
        'cartType': [cartType],
        'totalRent': [totalRent],
        'rentCartItemOffers': this._fb.array([
          this.initRentCartItemOffersForm(offerId)])
      });
  }

  initRentCartItemOffersForm(offerId) {
    return this._fb.group({
      'offerId': offerId
    });
  }
}